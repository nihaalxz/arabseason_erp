from django.shortcuts import render
from django.http import HttpResponse
from rest_framework import viewsets, permissions, status, views
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Sum, Count, Q, F, DecimalField, Subquery, OuterRef
from django.db.models.functions import TruncMonth, Coalesce
from django.utils import timezone
import datetime
import logging
from decimal import Decimal

logger = logging.getLogger(__name__)

from .models import (Customer, Vendor, JobOrder, CustomerPayment, VendorPayment, 
                    Expense, SiteSettings, PaymentRequest, ExpenseCategory, ExpenseType, Labour, ExcludedJobTitle,
                    PlanningTool, PlanningWorker, ProjectPlan, SalaryPayment,
                    CashBook, CashBookEntry, StaffTimesheet, BankAccount, PettyCashAccount,
                    Invoice, InvoiceItem, CustomFormField,
                    MaterialCategory, Material, Estimation, EstimationItem,
                    Quotation, QuotationItem, CreditNote, CreditNoteItem, DeliveryNote, DeliveryNoteItem,
                    Notification)
from .serializers import (CustomerSerializer, VendorSerializer, JobOrderSerializer, 
                        CustomerPaymentSerializer, VendorPaymentSerializer,
                        ExpenseSerializer, SiteSettingsSerializer,
                        JobOrderLookupSerializer, PaymentRequestSerializer,
                        ExpenseCategorySerializer, ExpenseTypeSerializer, LabourSerializer,
                        PlanningToolSerializer, PlanningWorkerSerializer, ProjectPlanSerializer,
                        SalaryPaymentSerializer, CashBookSerializer, CashBookEntrySerializer,
                        StaffTimesheetSerializer, BankAccountSerializer, PettyCashAccountSerializer,
                        InvoiceSerializer, InvoiceItemSerializer, CustomFormFieldSerializer,
                        MaterialCategorySerializer, MaterialSerializer,
                        EstimationSerializer, EstimationItemSerializer,
                        QuotationSerializer, QuotationItemSerializer,
                        CreditNoteSerializer, CreditNoteItemSerializer,
                        DeliveryNoteSerializer, DeliveryNoteItemSerializer,
                        NotificationSerializer)

def is_admin_user(user):
    return bool(user and user.is_authenticated and (user.is_superuser or user.is_staff or getattr(user, 'role', '') == 'Admin'))

class IsAdminRoleUser(permissions.BasePermission):
    """
    Permission check for users with role = 'Admin', staff, or superuser.
    """
    def has_permission(self, request, view):
        return is_admin_user(request.user)

class CustomerViewSet(viewsets.ModelViewSet):
    serializer_class = CustomerSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        jobs_sub = JobOrder.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
        invs_sub = Invoice.objects.filter(customer=OuterRef('pk'), job_order__isnull=True).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
        cns_sub = CreditNote.objects.filter(customer=OuterRef('pk')).exclude(status__in=['Draft', 'Cancelled']).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
        pays_sub = CustomerPayment.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('amount')).values('total')[:1]

        qs = Customer.objects.annotate(
            total_billed=Coalesce(Subquery(jobs_sub), Decimal('0'), output_field=DecimalField()) + Coalesce(Subquery(invs_sub), Decimal('0'), output_field=DecimalField()) - Coalesce(Subquery(cns_sub), Decimal('0'), output_field=DecimalField()),
            paid_amount=Coalesce(Subquery(pays_sub), Decimal('0'), output_field=DecimalField())
        ).select_related('created_by').order_by('name').distinct()

        if not is_admin_user(self.request.user):
            qs = qs.filter(created_by=self.request.user)
        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(name__icontains=search) |
                Q(email__icontains=search) |
                Q(phone__icontains=search) |
                Q(address__icontains=search)
            )
        pending_only = self.request.query_params.get('pending_only')
        if pending_only == 'true':
            qs = qs.filter(total_billed__gt=F('paid_amount'))
        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)

    @action(detail=False, methods=['get'])
    def summary(self, request):
        is_admin = is_admin_user(request.user)
        job_qs = JobOrder.objects.all() if is_admin else JobOrder.objects.filter(customer__created_by=request.user)
        inv_qs = Invoice.objects.filter(job_order__isnull=True) if is_admin else Invoice.objects.filter(customer__created_by=request.user, job_order__isnull=True)
        cn_qs = CreditNote.objects.exclude(status__in=['Draft', 'Cancelled']) if is_admin else CreditNote.objects.filter(customer__created_by=request.user).exclude(status__in=['Draft', 'Cancelled'])
        pay_qs = CustomerPayment.objects.all() if is_admin else CustomerPayment.objects.filter(customer__created_by=request.user)

        job_total = float(job_qs.aggregate(Sum('total_amount'))['total_amount__sum'] or 0)
        inv_total = float(inv_qs.aggregate(Sum('total_amount'))['total_amount__sum'] or 0)
        cn_total = float(cn_qs.aggregate(Sum('total_amount'))['total_amount__sum'] or 0)
        total_billed = (job_total + inv_total) - cn_total
        total_paid = float(pay_qs.aggregate(Sum('amount'))['amount__sum'] or 0)
        pending_balance = total_billed - total_paid

        cust_qs = Customer.objects.all() if is_admin else Customer.objects.filter(created_by=request.user)
        total_count = cust_qs.count()

        jobs_sub = JobOrder.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
        invs_sub = Invoice.objects.filter(customer=OuterRef('pk'), job_order__isnull=True).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
        cns_sub = CreditNote.objects.filter(customer=OuterRef('pk')).exclude(status__in=['Draft', 'Cancelled']).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
        pays_sub = CustomerPayment.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('amount')).values('total')[:1]
        pending_count = cust_qs.annotate(
            tb=Coalesce(Subquery(jobs_sub), Decimal('0'), output_field=DecimalField()) + Coalesce(Subquery(invs_sub), Decimal('0'), output_field=DecimalField()) - Coalesce(Subquery(cns_sub), Decimal('0'), output_field=DecimalField()),
            pa=Coalesce(Subquery(pays_sub), Decimal('0'), output_field=DecimalField())
        ).filter(tb__gt=F('pa')).count()

        return Response({
            'total_billed': total_billed,
            'paid_amount': total_paid,
            'pending_balance': pending_balance,
            'total_count': total_count,
            'pending_count': pending_count
        })

class VendorViewSet(viewsets.ModelViewSet):
    serializer_class = VendorSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = Vendor.objects.all().select_related('created_by').order_by('name')
        if not is_admin_user(self.request.user):
            qs = qs.filter(created_by=self.request.user)
        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(name__icontains=search) |
                Q(company__icontains=search) |
                Q(email__icontains=search) |
                Q(phone__icontains=search) |
                Q(address__icontains=search)
            )
        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)

class JobOrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)

    def get_queryset(self):
        queryset = JobOrder.objects.all().select_related('customer', 'vendor', 'created_by').prefetch_related('customer_payments')
        
        if not is_admin_user(self.request.user):
            queryset = queryset.filter(created_by=self.request.user)

        customer_id = self.request.query_params.get('customer')
        if customer_id and str(customer_id).lower() != 'all':
            if str(customer_id).isdigit():
                queryset = queryset.filter(customer_id=customer_id)
            else:
                queryset = queryset.filter(customer__name=customer_id)
            
        status_filter = self.request.query_params.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
            
        search_query = self.request.query_params.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(title__icontains=search_query) |
                Q(order_id__icontains=search_query) |
                Q(customer__name__icontains=search_query) |
                Q(vendor__name__icontains=search_query)
            )
            
        payment_status = self.request.query_params.get('payment_status')
        if payment_status:
            queryset = queryset.annotate(
                total_paid=Coalesce(Sum('customer_payments__amount'), Decimal('0'), output_field=DecimalField())
            )
            if payment_status == 'paid':
                queryset = queryset.filter(total_amount__lte=F('total_paid'))
            elif payment_status == 'unpaid':
                queryset = queryset.filter(total_amount__gt=F('total_paid'))

        ordering = self.request.query_params.get('ordering')
        if ordering:
            valid_orderings = {
                'order_id': 'order_id',
                '-order_id': '-order_id',
                'id': 'id',
                '-id': '-id',
                'title': 'title',
                '-title': '-title',
                'status': 'status',
                '-status': '-status',
                'total_amount': 'total_amount',
                '-total_amount': '-total_amount',
                'customer': 'customer__name',
                '-customer': '-customer__name',
                'customer__name': 'customer__name',
                '-customer__name': '-customer__name',
                'created_at': 'created_at',
                '-created_at': '-created_at',
            }
            if ordering in valid_orderings:
                queryset = queryset.order_by(valid_orderings[ordering])
            else:
                queryset = queryset.order_by('-created_at')
        else:
            queryset = queryset.order_by('-created_at')
                
        return queryset.distinct()

    def perform_create(self, serializer):
        user = self.request.user
        customer_obj = serializer.validated_data.get('customer')
        advance_amount = serializer.validated_data.get('advance_amount', Decimal('0'))
        payment_type = serializer.validated_data.get('payment_type', 'full')

        # 4.3 — Compute prior_balance: sum of all previous jobs' and standalone invoices' minus credit notes and payments
        prior_balance = Decimal('0')
        if customer_obj:
            cid = customer_obj.id if hasattr(customer_obj, 'id') else customer_obj
            total_prior_billed = JobOrder.objects.filter(customer_id=cid).aggregate(
                tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
            )['tot']
            total_prior_invoices = Invoice.objects.filter(customer_id=cid, job_order__isnull=True).aggregate(
                tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
            )['tot']
            total_prior_cn = CreditNote.objects.filter(customer_id=cid).exclude(status__in=['Draft', 'Cancelled']).aggregate(
                tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
            )['tot']
            total_prior_paid = CustomerPayment.objects.filter(customer_id=cid).aggregate(
                tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField())
            )['tot']
            prior_balance = max(Decimal('0'), (total_prior_billed + total_prior_invoices - total_prior_cn) - total_prior_paid)

        created_by_staff = serializer.validated_data.get('created_by_staff')
        if not created_by_staff and user and user.is_authenticated:
            full = f"{user.first_name} {user.last_name}".strip()
            created_by_staff = full or user.username

        job = serializer.save(
            created_by=user,
            created_by_staff=created_by_staff,
            prior_balance=prior_balance
        )

        # If advance_amount provided, auto-create a CustomerPayment tagged as 'advance'
        if advance_amount and float(advance_amount) > 0:
            import datetime
            CustomerPayment.objects.create(
                customer=job.customer,
                job_order=job,
                amount=advance_amount,
                payment_date=datetime.date.today(),
                payment_type='advance',
                notes=f"Advance payment at job creation ({job.order_id or job.id})",
                created_by=user
            )

    def perform_update(self, serializer):
        job = serializer.save()
        advance_amount = Decimal(str(job.advance_amount or 0))
        # Keep advance CustomerPayment in sync if updated
        adv_payment = CustomerPayment.objects.filter(job_order=job, payment_type='advance').first()
        user = self.request.user if self.request.user.is_authenticated else None
        if advance_amount > 0:
            import datetime
            if adv_payment:
                adv_payment.amount = advance_amount
                adv_payment.save(update_fields=['amount'])
            else:
                CustomerPayment.objects.create(
                    customer=job.customer,
                    job_order=job,
                    amount=advance_amount,
                    payment_date=datetime.date.today(),
                    payment_type='advance',
                    notes=f"Advance payment for job ({job.order_id or job.id})",
                    created_by=user
                )
        elif adv_payment and advance_amount == 0:
            adv_payment.delete()

    @action(detail=False, methods=['get'], url_path='prior-balance')
    def prior_balance(self, request):
        customer_id = request.query_params.get('customer')
        if not customer_id:
            return Response({'prior_balance': 0.0, 'total_billed': 0.0, 'total_paid': 0.0})
        
        jobs_tot = JobOrder.objects.filter(customer_id=customer_id).aggregate(
            tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        inv_tot = Invoice.objects.filter(customer_id=customer_id, job_order__isnull=True).aggregate(
            tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        cn_tot = CreditNote.objects.filter(customer_id=customer_id).exclude(status__in=['Draft', 'Cancelled']).aggregate(
            tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        paid_tot = CustomerPayment.objects.filter(customer_id=customer_id).aggregate(
            tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        net_billed = jobs_tot + inv_tot - cn_tot
        prior_bal = max(Decimal('0'), net_billed - paid_tot)
        return Response({
            'customer_id': int(customer_id) if str(customer_id).isdigit() else customer_id,
            'prior_balance': float(prior_bal),
            'total_billed': float(net_billed),
            'total_paid': float(paid_tot)
        })

    @action(detail=False, methods=['get'], url_path='staff-options')
    def staff_options(self, request):
        from accounts.models import CustomUser
        users = CustomUser.objects.filter(is_active=True).values('id', 'username', 'first_name', 'last_name')
        staff_list = []
        for u in users:
            full = f"{u['first_name']} {u['last_name']}".strip()
            name = full if full else u['username']
            staff_list.append({
                'id': u['id'],
                'username': u['username'],
                'name': name
            })
        return Response(staff_list)

    def get_serializer_class(self):
        if self.request.query_params.get('lookup') == 'true':
            return JobOrderLookupSerializer
        return JobOrderSerializer

    @action(detail=False, methods=['get'])
    def titles(self, request):
        excluded = ExcludedJobTitle.objects.values_list('title', flat=True)
        qs = JobOrder.objects.all()
        if not is_admin_user(request.user):
            qs = qs.filter(created_by=request.user)
        titles = qs.exclude(title__in=excluded).values_list('title', flat=True).distinct().order_by('title')
        return Response(list(titles))

    @action(detail=False, methods=['post'], url_path='delete-title')
    def delete_title(self, request):
        title = request.data.get('title')
        if not title:
            return Response({'error': 'Title is required'}, status=status.HTTP_400_BAD_REQUEST)
        ExcludedJobTitle.objects.get_or_create(title=title)
        excluded = ExcludedJobTitle.objects.values_list('title', flat=True)
        qs = JobOrder.objects.all()
        if not is_admin_user(request.user):
            qs = qs.filter(created_by=request.user)
        titles = qs.exclude(title__in=excluded).values_list('title', flat=True).distinct().order_by('title')
        return Response(list(titles))

    @action(detail=True, methods=['get'], url_path='credit-summary')
    def credit_summary(self, request, pk=None):
        """
        4.3 — Returns the complete credit breakdown for a job order:
        prior_balance, job total, grand total owed, advance paid, and outstanding.
        """
        job = self.get_object()
        paid_on_job = float(
            CustomerPayment.objects.filter(job_order=job)
            .aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        )
        advance_on_job = float(
            CustomerPayment.objects.filter(job_order=job, payment_type='advance')
            .aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        )
        balance_this_job = float(job.total_amount) - paid_on_job
        outstanding = float(job.prior_balance) + balance_this_job
        grand_total = float(job.prior_balance) + float(job.total_amount)

        payments = CustomerPayment.objects.filter(job_order=job).order_by('payment_date')
        history = [
            {
                'id': p.id,
                'amount': float(p.amount),
                'date': str(p.payment_date),
                'payment_type': p.payment_type,
                'payment_type_display': p.get_payment_type_display(),
                'notes': p.notes
            }
            for p in payments
        ]

        return Response({
            'job_id': job.id,
            'job_title': job.title,
            'job_total': float(job.total_amount),
            'prior_balance': float(job.prior_balance),
            'grand_total': round(grand_total, 2),
            'advance_paid': round(advance_on_job, 2),
            'paid_on_job': round(paid_on_job, 2),
            'balance_this_job': round(balance_this_job, 2),
            'outstanding': round(outstanding, 2),
            'payment_type': job.payment_type,
            'payment_history': history
        })

    @action(detail=False, methods=['get'], url_path='summary')
    def summary(self, request):
        from .models import Customer
        qs = self.get_queryset()
        
        total_val = qs.aggregate(tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField()))['tot']
        total_paid = CustomerPayment.objects.filter(job_order__in=qs).aggregate(
            tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        total_balance = max(Decimal('0'), total_val - total_paid)
        count = qs.count()

        # Build client breakdown
        customers = Customer.objects.all()
        if not is_admin_user(request.user):
            customers = customers.filter(created_by=request.user)
        
        client_breakdown = []
        for cust in customers:
            cust_jobs = JobOrder.objects.filter(customer=cust)
            if not is_admin_user(request.user):
                cust_jobs = cust_jobs.filter(created_by=request.user)
            c_count = cust_jobs.count()
            if c_count > 0:
                c_val = cust_jobs.aggregate(tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField()))['tot']
                c_paid = CustomerPayment.objects.filter(job_order__in=cust_jobs).aggregate(
                    tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField())
                )['tot']
                client_breakdown.append({
                    'customer_id': cust.id,
                    'customer_name': cust.name,
                    'count': c_count,
                    'total_value': float(c_val),
                    'total_paid': float(c_paid),
                    'total_balance': float(max(Decimal('0'), c_val - c_paid))
                })

        return Response({
            'total_value': float(total_val),
            'total_paid': float(total_paid),
            'total_balance': float(total_balance),
            'count': count,
            'by_client': client_breakdown
        })

class CustomerPaymentViewSet(viewsets.ModelViewSet):
    serializer_class = CustomerPaymentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = CustomerPayment.objects.all().select_related('customer', 'job_order', 'created_by').order_by('-payment_date')
        if not is_admin_user(self.request.user):
            queryset = queryset.filter(
                Q(created_by=self.request.user) |
                Q(job_order__created_by=self.request.user) |
                Q(customer__created_by=self.request.user)
            )
        customer_id = self.request.query_params.get('customer')
        if customer_id:
            queryset = queryset.filter(customer_id=customer_id)
        job_order_id = self.request.query_params.get('job_order')
        if job_order_id:
            queryset = queryset.filter(job_order_id=job_order_id)
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(customer__name__icontains=search) |
                Q(job_order__title__icontains=search) |
                Q(job_order__order_id__icontains=search) |
                Q(notes__icontains=search)
            )
        return queryset

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)

class VendorPaymentViewSet(viewsets.ModelViewSet):
    serializer_class = VendorPaymentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = VendorPayment.objects.all().select_related('vendor', 'job_order', 'created_by').order_by('-payment_date')
        if not is_admin_user(self.request.user):
            queryset = queryset.filter(
                Q(created_by=self.request.user) |
                Q(job_order__created_by=self.request.user) |
                Q(vendor__created_by=self.request.user)
            )
        vendor_id = self.request.query_params.get('vendor')
        if vendor_id:
            queryset = queryset.filter(vendor_id=vendor_id)
        job_order_id = self.request.query_params.get('job_order')
        if job_order_id:
            queryset = queryset.filter(job_order_id=job_order_id)
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(vendor__name__icontains=search) |
                Q(job_order__title__icontains=search) |
                Q(job_order__order_id__icontains=search) |
                Q(notes__icontains=search)
            )
        return queryset

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class ExpenseViewSet(viewsets.ModelViewSet):
    serializer_class = ExpenseSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)

    def get_queryset(self):
        queryset = Expense.objects.all().select_related('vendor', 'job_order', 'created_by').order_by('-date')
        if not is_admin_user(self.request.user):
            queryset = queryset.filter(
                Q(created_by=self.request.user) |
                Q(job_order__created_by=self.request.user)
            )
        job_order = self.request.query_params.get('job_order')
        if job_order:
            queryset = queryset.filter(job_order_id=job_order)
        category = self.request.query_params.get('category')
        if category and category != 'all':
            queryset = queryset.filter(category=category)
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(description__icontains=search) |
                Q(vendor__name__icontains=search) |
                Q(job_order__title__icontains=search) |
                Q(job_order__order_id__icontains=search) |
                Q(category__icontains=search) |
                Q(type__icontains=search) |
                Q(notes__icontains=search)
            )
        return queryset

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='summary')
    def summary(self, request):
        qs = self.get_queryset()
        total_amount = qs.aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        categories = qs.values('category').annotate(
            total=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()),
            count=Count('id')
        ).order_by('-total')
        return Response({
            'total_amount': float(total_amount),
            'total_count': qs.count(),
            'categories': list(categories)
        })

class PaymentRequestViewSet(viewsets.ModelViewSet):
    serializer_class = PaymentRequestSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = PaymentRequest.objects.all().select_related('vendor', 'created_by').order_by('-created_at')
        if not is_admin_user(self.request.user):
            queryset = queryset.filter(created_by=self.request.user)
        status_filter = self.request.query_params.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(
                Q(title__icontains=search) |
                Q(description__icontains=search) |
                Q(vendor__name__icontains=search) |
                Q(requested_by__icontains=search) |
                Q(status__icontains=search) |
                Q(admin_note__icontains=search)
            )
        return queryset

    def perform_create(self, serializer):
        req_by = self.request.user.get_full_name() or self.request.user.username
        serializer.save(created_by=self.request.user, requested_by=req_by)

class ExpenseCategoryViewSet(viewsets.ModelViewSet):
    queryset = ExpenseCategory.objects.all().order_by('name')
    serializer_class = ExpenseCategorySerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        name = str(request.data.get('name', '')).strip()
        if not name:
            return Response({"detail": "Name is required"}, status=status.HTTP_400_BAD_REQUEST)
            
        existing = ExpenseCategory.objects.filter(name__iexact=name).first()
        if existing:
            return Response({"detail": "Category already exists."}, status=status.HTTP_400_BAD_REQUEST)
            
        mutable_data = request.data.copy() if hasattr(request.data, 'copy') else dict(request.data)
        mutable_data['name'] = name
        serializer = self.get_serializer(data=mutable_data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if Expense.objects.filter(category=instance.name).exists():
            return Response({"message": "Cannot delete category as it is currently in use by one or more expenses."}, status=status.HTTP_400_BAD_REQUEST)
        return super().destroy(request, *args, **kwargs)

class ExpenseTypeViewSet(viewsets.ModelViewSet):
    queryset = ExpenseType.objects.all().order_by('name')
    serializer_class = ExpenseTypeSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        name = str(request.data.get('name', '')).strip()
        if not name:
            return Response({"detail": "Name is required"}, status=status.HTTP_400_BAD_REQUEST)
            
        existing = ExpenseType.objects.filter(name__iexact=name).first()
        if existing:
            return Response({"detail": "Type already exists."}, status=status.HTTP_400_BAD_REQUEST)
            
        mutable_data = request.data.copy() if hasattr(request.data, 'copy') else dict(request.data)
        mutable_data['name'] = name
        serializer = self.get_serializer(data=mutable_data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if Expense.objects.filter(type=instance.name).exists():
            return Response({"message": "Cannot delete type as it is currently in use by one or more expenses."}, status=status.HTTP_400_BAD_REQUEST)
        return super().destroy(request, *args, **kwargs)

class LabourViewSet(viewsets.ModelViewSet):
    serializer_class = LabourSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = Labour.objects.all().select_related('vendor', 'created_by').order_by('-date')
        if not is_admin_user(self.request.user):
            queryset = queryset.filter(created_by=self.request.user)
        return queryset

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class DashboardAPIView(views.APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')
        
        if start_date_str and end_date_str:
            try:
                start_date = datetime.datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date = datetime.datetime.strptime(end_date_str, '%Y-%m-%d').date()
            except ValueError:
                end_date = timezone.now().date()
                start_date = end_date - datetime.timedelta(days=30)
        else:
            end_date = timezone.now().date()
            start_date = end_date - datetime.timedelta(days=30)
        
        is_admin = is_admin_user(request.user)
        
        cust_qs = Customer.objects.all() if is_admin else Customer.objects.filter(created_by=request.user)
        job_qs = JobOrder.objects.all() if is_admin else JobOrder.objects.filter(created_by=request.user)
        cust_pay_qs = CustomerPayment.objects.all() if is_admin else CustomerPayment.objects.filter(Q(created_by=request.user) | Q(job_order__created_by=request.user))
        exp_qs = Expense.objects.all() if is_admin else Expense.objects.filter(Q(created_by=request.user) | Q(job_order__created_by=request.user))
        pay_req_qs = PaymentRequest.objects.all() if is_admin else PaymentRequest.objects.filter(created_by=request.user)
        labour_qs = Labour.objects.all() if is_admin else Labour.objects.filter(created_by=request.user)

        total_customers = cust_qs.count()
        total_job_orders = job_qs.filter(status__in=['Pending', 'In Progress']).count()
        
        income_range = {'payment_date__range': (start_date, end_date)}
        expense_range = {'date__range': (start_date, end_date)}
        labour_range = {'date__range': (start_date, end_date)}
        job_range = {'created_at__date__range': (start_date, end_date)}
        
        total_income = cust_pay_qs.filter(**income_range).aggregate(Sum('amount'))['amount__sum'] or 0
        total_exp = exp_qs.filter(**expense_range).aggregate(Sum('amount'))['amount__sum'] or 0
        total_vend = pay_req_qs.filter(status='Approved', created_at__date__range=(start_date, end_date)).aggregate(Sum('amount'))['amount__sum'] or 0
        total_labour = labour_qs.filter(**labour_range).aggregate(Sum('payment_amount'))['payment_amount__sum'] or 0
        
        total_outgoing = float(total_exp) + float(total_vend) + float(total_labour)
        
        # Jobs by status in range
        jobs_in_range = job_qs.filter(**job_range)
        jobs_by_status = {
            'Pending': jobs_in_range.filter(status='Pending').count(),
            'In Progress': jobs_in_range.filter(status='In Progress').count(),
            'Completed': jobs_in_range.filter(status='Completed').count(),
            'Cancelled': jobs_in_range.filter(status='Cancelled').count(),
        }
        
        # Recent jobs
        recent_jobs = job_qs.select_related('customer').order_by('-created_at')[:5]
        recent_jobs_data = []
        for job in recent_jobs:
            recent_jobs_data.append({
                'id': job.id,
                'title': job.title,
                'customer_name': job.customer.name if job.customer else 'Unknown',
                'total_amount': float(job.total_amount)
            })

        # Trends
        daily_income = cust_pay_qs.filter(**income_range).values('payment_date').annotate(total=Sum('amount'))
        daily_expenses = exp_qs.filter(**expense_range).values('date').annotate(total=Sum('amount'))
        daily_labour = labour_qs.filter(**labour_range).values('date').annotate(total=Sum('payment_amount'))
        
        daily_trends = []
        curr = start_date
        while curr <= end_date:
            inc = next((i['total'] for i in daily_income if i['payment_date'] == curr), 0)
            exp = next((e['total'] for e in daily_expenses if e['date'] == curr), 0)
            lab = next((l['total'] for l in daily_labour if l['date'] == curr), 0)
            
            daily_trends.append({
                'date': str(curr), 
                'income': float(inc),
                'expenses': float(exp) + float(lab)
            })
            curr += datetime.timedelta(days=1)

        total_cust_cn = CreditNote.objects.exclude(status__in=['Draft', 'Cancelled']).aggregate(tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField()))['tot']
        total_cust_billed = (job_qs.aggregate(tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField()))['tot'] +
                             Invoice.objects.filter(job_order__isnull=True).aggregate(tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField()))['tot'] -
                             total_cust_cn)
        total_cust_paid = cust_pay_qs.aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        total_receivables = float(max(Decimal('0'), total_cust_billed - total_cust_paid))

        total_vend_billed = exp_qs.aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        total_vend_paid = (VendorPayment.objects.all().aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot'] +
                           pay_req_qs.filter(status='Approved').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot'])
        total_payables = float(max(Decimal('0'), total_vend_billed - total_vend_paid))

        cb_opening = CashBook.objects.aggregate(tot=Coalesce(Sum('opening_balance'), Decimal('0'), output_field=DecimalField()))['tot']
        cb_in = CashBookEntry.objects.filter(entry_type='in', cashbook__isnull=False).exclude(approval_status='rejected').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        cb_out = CashBookEntry.objects.filter(entry_type='out', cashbook__isnull=False).exclude(approval_status='rejected').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        cb_balance = cb_opening + cb_in - cb_out
        bank_balance = BankAccount.objects.aggregate(tot=Coalesce(Sum('balance'), Decimal('0'), output_field=DecimalField()))['tot']
        petty_balance = PettyCashAccount.objects.aggregate(tot=Coalesce(Sum('balance'), Decimal('0'), output_field=DecimalField()))['tot']
        total_cash_balance = float(cb_balance + bank_balance + petty_balance)

        return Response({
            'total_customers': total_customers,
            'total_job_orders': total_job_orders,
            'total_income': float(total_income),
            'total_outgoing': total_outgoing,
            'total_receivables': total_receivables,
            'total_payables': total_payables,
            'cash_balance': total_cash_balance,
            'jobs_by_status': jobs_by_status,
            'recent_jobs': recent_jobs_data,
            'daily_trends': daily_trends
        })

class ReportAPIView(views.APIView):
    permission_classes = [IsAuthenticated]

    def perform_content_negotiation(self, request, force=False):
        # Prevent DRF 404 when format=pdf is passed as a query parameter
        if request.query_params.get('format') == 'pdf' or request.query_params.get('export_format') == 'pdf':
            renderers = self.get_renderers()
            return renderers[0], renderers[0].media_type
        return super().perform_content_negotiation(request, force=force)
    
    def get(self, request):
        try:
            start_date_str = request.query_params.get('start_date')
            end_date_str = request.query_params.get('end_date')
            
            if start_date_str and end_date_str:
                start_date = datetime.datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date = datetime.datetime.strptime(end_date_str, '%Y-%m-%d').date()
            else:
                end_date = timezone.now().date()
                start_date = end_date - datetime.timedelta(days=365)

            is_admin = is_admin_user(request.user)

            # Scoped base querysets
            job_base = JobOrder.objects.all() if is_admin else JobOrder.objects.filter(created_by=request.user)
            cust_base = Customer.objects.all() if is_admin else Customer.objects.filter(created_by=request.user)
            vend_base = Vendor.objects.all() if is_admin else Vendor.objects.filter(created_by=request.user)
            cust_pay_base = CustomerPayment.objects.all() if is_admin else CustomerPayment.objects.filter(Q(created_by=request.user) | Q(job_order__created_by=request.user))
            exp_base = Expense.objects.all() if is_admin else Expense.objects.filter(Q(created_by=request.user) | Q(job_order__created_by=request.user))
            vend_pay_base = VendorPayment.objects.all() if is_admin else VendorPayment.objects.filter(Q(created_by=request.user) | Q(job_order__created_by=request.user))
            pay_req_base = PaymentRequest.objects.all() if is_admin else PaymentRequest.objects.filter(created_by=request.user)
            labour_base = Labour.objects.all() if is_admin else Labour.objects.filter(created_by=request.user)

            # 1. Financial Trends
            monthly_income = cust_pay_base.filter(payment_date__range=(start_date, end_date))\
                .annotate(month=TruncMonth('payment_date')).values('month').annotate(total=Sum('amount')).order_by('month')
            
            monthly_expenses = exp_base.filter(date__range=(start_date, end_date))\
                .annotate(month=TruncMonth('date')).values('month').annotate(total=Sum('amount')).order_by('month')

            # 2. Customer Aggregate (including standalone invoices & credit notes)
            cust_job_rev = JobOrder.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
            cust_inv_rev = Invoice.objects.filter(customer=OuterRef('pk'), job_order__isnull=True).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
            cust_cn_rev = CreditNote.objects.filter(customer=OuterRef('pk')).exclude(status__in=['Draft', 'Cancelled']).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
            cust_paid = CustomerPayment.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('amount')).values('total')[:1]

            customers = cust_base.annotate(
                total_jobs=Count('job_orders', distinct=True),
                job_rev_sum=Coalesce(Subquery(cust_job_rev, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
                inv_rev_sum=Coalesce(Subquery(cust_inv_rev, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
                cn_rev_sum=Coalesce(Subquery(cust_cn_rev, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
                paid_sum=Coalesce(Subquery(cust_paid, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0'))
            ).annotate(
                rev_sum=F('job_rev_sum') + F('inv_rev_sum') - F('cn_rev_sum'),
                total_revenue=F('job_rev_sum') + F('inv_rev_sum') - F('cn_rev_sum'),
                balance=F('job_rev_sum') + F('inv_rev_sum') - F('cn_rev_sum') - F('paid_sum')
            ).values('id', 'name', 'email', 'phone', 'total_jobs', 'rev_sum', 'total_revenue', 'paid_sum', 'balance')

            # 3. Vendor Aggregate (including VendorPayment and PaymentRequest)
            vend_purch = Expense.objects.filter(vendor=OuterRef('pk')).values('vendor').annotate(total=Sum('amount')).values('total')[:1]
            vend_vp = VendorPayment.objects.filter(vendor=OuterRef('pk')).values('vendor').annotate(total=Sum('amount')).values('total')[:1]
            vend_pr = PaymentRequest.objects.filter(vendor=OuterRef('pk'), status='Approved').values('vendor').annotate(total=Sum('amount')).values('total')[:1]

            vendors = vend_base.annotate(
                total_purchases=Count('expenses', distinct=True),
                purch_sum=Coalesce(Subquery(vend_purch, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
                vp_paid_sum=Coalesce(Subquery(vend_vp, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
                pr_paid_sum=Coalesce(Subquery(vend_pr, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
            ).annotate(
                paid_sum=F('vp_paid_sum') + F('pr_paid_sum'),
                total_paid=F('vp_paid_sum') + F('pr_paid_sum'),
                balance=F('purch_sum') - (F('vp_paid_sum') + F('pr_paid_sum'))
            ).values('id', 'name', 'business_group', 'email', 'phone', 'total_purchases', 'purch_sum', 'total_paid', 'balance')

            # 4. Job Orders Aggregate
            job_paid_sq = CustomerPayment.objects.filter(job_order=OuterRef('pk')).values('job_order').annotate(total=Sum('amount')).values('total')[:1]
            
            jobs = job_base.select_related('customer').annotate(
                paid=Coalesce(Subquery(job_paid_sq, output_field=DecimalField()), Decimal('0')),
                balance=F('total_amount') - Coalesce(Subquery(job_paid_sq, output_field=DecimalField()), Decimal('0'))
            ).values('id', 'order_id', 'title', 'customer__name', 'status', 'total_amount', 'paid', 'balance')

            # 5. Job P&L (if job_id provided)
            job_id = request.query_params.get('job_id')
            job_pl = None
            if job_id:
                try:
                    job_obj = job_base.get(id=job_id)
                    rev = cust_pay_base.filter(job_order=job_obj).aggregate(Sum('amount'))['amount__sum'] or 0
                    exp = exp_base.filter(job_order=job_obj).aggregate(Sum('amount'))['amount__sum'] or 0
                    job_pl = {
                        'job_id': job_obj.id,
                        'title': job_obj.title,
                        'client_name': job_obj.customer.name if job_obj.customer else 'Unknown',
                        'status': job_obj.status,
                        'contract_total': float(job_obj.total_amount),
                        'revenue': float(rev),
                        'expenses': float(exp),
                        'profit': float(rev) - float(exp)
                    }
                except (JobOrder.DoesNotExist, ValueError): pass

            # 6. Expense Report Data
            expenses_qs = exp_base.order_by('-date')
            if start_date_str and end_date_str:
                expenses_qs = expenses_qs.filter(date__range=(start_date, end_date))
                
            opening_balance_qs = exp_base.filter(is_opening_balance=True, date__lte=end_date)
            opening_balance = opening_balance_qs.aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            
            all_income = cust_pay_base.filter(payment_date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            # Deduplicate vendor payments from expense bills: direct operational expenses + max(vendor incurred expenses, vendor cash payments) + labour
            direct_exp = exp_base.filter(is_opening_balance=False, vendor__isnull=True, date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            vendor_exp = exp_base.filter(is_opening_balance=False, vendor__isnull=False, date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            all_vendor_req = pay_req_base.filter(status='Approved', created_at__date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            all_vendor_pay = vend_pay_base.filter(payment_date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            vendor_outflow = max(vendor_exp, all_vendor_req + all_vendor_pay)
            all_labour = labour_base.filter(date__lte=end_date).aggregate(Sum('payment_amount'))['payment_amount__sum'] or Decimal('0')
            
            bank_balance = float(opening_balance + all_income - direct_exp - vendor_outflow - all_labour)
            
            expense_list = list(expenses_qs.filter(is_opening_balance=False).values(
                'id', 'date', 'description', 'amount', 'category', 'type', 'notes'
            ))
            
            expense_report = {
                'opening_balance': float(opening_balance),
                'bank_balance': bank_balance,
                'closing_balance': bank_balance,
                'expenses': expense_list
            }

            # Safe date formatting helper
            def fmt_month(dt):
                if not dt: return ''
                if hasattr(dt, 'strftime'): return dt.strftime('%Y-%m')
                return str(dt)[:7] # Fallback for strings

            report_payload = {
                'monthly_income': [{'month': fmt_month(i['month']), 'total': float(i['total'] or 0)} for i in monthly_income],
                'monthly_expenses': [{'month': fmt_month(e['month']), 'total': float(e['total'] or 0)} for e in monthly_expenses],
                'customers': list(customers),
                'vendors': list(vendors),
                'jobs': [{**j, 'order_id': j['order_id'] or f"#JOB{j['id']}"} for j in jobs],
                'job_pl': job_pl,
                'expense_report': expense_report
            }

            if request.query_params.get('export_format') == 'pdf' or request.query_params.get('format') == 'pdf' or request.query_params.get('pdf') == 'true':
                from django.http import HttpResponse
                from .pdf_generator import universal_pdf_generator, format_dynamic_filename
                tab = request.query_params.get('tab', 'overview')
                filters = {
                    'start_date': str(start_date) if start_date else None,
                    'end_date': str(end_date) if end_date else None,
                    'job_id': job_id
                }
                pdf_bytes = universal_pdf_generator.generate_financial_report_pdf(tab, report_payload, filters)
                s_str = str(start_date) if start_date else None
                e_str = str(end_date) if end_date else datetime.datetime.now().strftime('%Y%m%d')
                filename = format_dynamic_filename('financial_report', tab, s_str, 'to' if s_str else None, e_str)
                response = HttpResponse(pdf_bytes, content_type='application/pdf')
                response['Content-Disposition'] = f'inline; filename="{filename}"'
                return response

            return Response(report_payload)

        except Exception as e:
            logger.exception("Report generation failed")
            return Response({'detail': str(e)}, status=500)

class SettingsAPIView(views.APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        s, _ = SiteSettings.objects.get_or_create(id=1)
        return Response(SiteSettingsSerializer(s).data)
    def post(self, request):
        if not (request.user.is_staff or request.user.is_superuser or getattr(request.user, 'role', '') == 'Admin'):
            return Response({'detail': 'You do not have permission to modify site settings.'}, status=403)
        s, _ = SiteSettings.objects.get_or_create(id=1)
        ser = SiteSettingsSerializer(s, data=request.data, partial=True)
        if ser.is_valid():
            ser.save()
            return Response(ser.data)
        return Response(ser.errors, status=400)

class ChangePasswordView(views.APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        u = request.user
        if not u.check_password(request.data.get('current_password')):
            return Response({'detail': 'Incorrect password'}, status=400)
        u.set_password(request.data.get('new_password'))
        u.save()
        return Response({'status': 'Password updated'})

class PlanningToolViewSet(viewsets.ModelViewSet):
    serializer_class = PlanningToolSerializer
    permission_classes = [IsAuthenticated]
    queryset = PlanningTool.objects.all().order_by('name')
    pagination_class = None

    def get_queryset(self):
        qs = PlanningTool.objects.all().order_by('name')
        q = self.request.query_params.get('search')
        if q:
            qs = qs.filter(name__icontains=q)
        return qs

class PlanningWorkerViewSet(viewsets.ModelViewSet):
    serializer_class = PlanningWorkerSerializer
    permission_classes = [IsAuthenticated]
    queryset = PlanningWorker.objects.all().order_by('name')
    pagination_class = None

    def get_queryset(self):
        qs = PlanningWorker.objects.all().order_by('name')
        q = self.request.query_params.get('search')
        if q:
            qs = qs.filter(name__icontains=q)
        return qs

class ProjectPlanViewSet(viewsets.ModelViewSet):
    serializer_class = ProjectPlanSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = ProjectPlan.objects.select_related('job_order', 'job_order__customer', 'created_by').all()
        job_id = self.request.query_params.get('job_order')
        if job_id:
            qs = qs.filter(job_order_id=job_id)
        status_filter = self.request.query_params.get('status')
        if status_filter:
            qs = qs.filter(status=status_filter)
        q = self.request.query_params.get('search')
        if q:
            qs = qs.filter(
                Q(title__icontains=q) | 
                Q(description__icontains=q) | 
                Q(job_order__title__icontains=q) | 
                Q(job_order__order_id__icontains=q) |
                Q(job_order__customer__name__icontains=q)
            )
        return qs.order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class SalaryPaymentViewSet(viewsets.ModelViewSet):
    serializer_class = SalaryPaymentSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = None

    def get_queryset(self):
        qs = SalaryPayment.objects.select_related('created_by').all()
        month = self.request.query_params.get('paid_month')
        if month:
            qs = qs.filter(paid_month=month)
        q = self.request.query_params.get('search')
        if q:
            qs = qs.filter(
                Q(staff_name__icontains=q) |
                Q(paid_month__icontains=q) |
                Q(description__icontains=q)
            )
        return qs.order_by('-payment_date', '-created_at')

    def perform_create(self, serializer):
        data = serializer.validated_data
        if not data.get('payment_date'):
            serializer.validated_data['payment_date'] = timezone.now().date()
        base = data.get('base_salary') or Decimal('0.00')
        ot_amt = data.get('overtime_amount') or Decimal('0.00')
        tot = data.get('total_salary')
        if not tot or tot <= 0:
            tot = base + ot_amt
            if tot <= 0 and data.get('amount'):
                tot = data.get('amount')
        serializer.save(created_by=self.request.user, total_salary=tot)

    def perform_update(self, serializer):
        data = serializer.validated_data
        base = data.get('base_salary') or serializer.instance.base_salary or Decimal('0.00')
        ot_amt = data.get('overtime_amount') or serializer.instance.overtime_amount or Decimal('0.00')
        tot = data.get('total_salary')
        if not tot or tot <= 0:
            tot = base + ot_amt
            if tot <= 0 and (data.get('amount') or serializer.instance.amount):
                tot = data.get('amount') or serializer.instance.amount
        serializer.save(total_salary=tot)

    @action(detail=False, methods=['get'], url_path='ledger')
    def ledger(self, request):
        """
        Calculates per-employee running ledger carrying forward pending balances month-to-month.
        """
        records = SalaryPayment.objects.all().order_by('payment_date', 'created_at', 'id')
        staff_filter = request.query_params.get('staff_name')
        if staff_filter:
            records = records.filter(staff_name__icontains=staff_filter)

        grouped = {}
        for r in records:
            name = r.staff_name.strip()
            if name not in grouped:
                grouped[name] = []
            grouped[name].append(r)

        result = []
        for name, emp_records in grouped.items():
            running_balance = Decimal('0.00')
            total_salary_acc = Decimal('0.00')
            total_paid_acc = Decimal('0.00')
            total_base_acc = Decimal('0.00')
            total_ot_hours_acc = Decimal('0.00')
            total_ot_amt_acc = Decimal('0.00')
            entries = []

            for r in emp_records:
                base = r.base_salary or Decimal('0.00')
                ot_hrs = r.overtime_hours or Decimal('0.00')
                ot_amt = r.overtime_amount or Decimal('0.00')
                tot = r.total_salary if (r.total_salary and r.total_salary > 0) else (base + ot_amt)
                paid = r.amount or Decimal('0.00')

                starting_bal = running_balance
                period_pending = tot - paid
                running_balance += period_pending

                total_base_acc += base
                total_ot_hours_acc += ot_hrs
                total_ot_amt_acc += ot_amt
                total_salary_acc += tot
                total_paid_acc += paid

                entries.append({
                    'id': r.id,
                    'paid_month': r.paid_month,
                    'payment_date': str(r.payment_date),
                    'description': r.description,
                    'base_salary': float(base),
                    'overtime_hours': float(ot_hrs),
                    'overtime_amount': float(ot_amt),
                    'total_salary': float(tot),
                    'amount_paid': float(paid),
                    'period_pending': float(period_pending),
                    'starting_balance': float(starting_bal),
                    'running_balance': float(running_balance),
                    'created_by_name': r.created_by.username if r.created_by else 'System'
                })

            result.append({
                'staff_name': name,
                'total_base_salary': float(total_base_acc),
                'total_overtime_hours': float(total_ot_hours_acc),
                'total_overtime_amount': float(total_ot_amt_acc),
                'total_salary_owed': float(total_salary_acc),
                'total_amount_paid': float(total_paid_acc),
                'current_pending_balance': float(running_balance),
                'entries_count': len(entries),
                'last_payment_date': str(emp_records[-1].payment_date) if emp_records else None,
                'entries': entries
            })

        # Sort by pending balance descending (employees with pending balance first)
        result.sort(key=lambda x: (x['current_pending_balance'] <= 0, -x['current_pending_balance'], x['staff_name'].lower()))
        return Response(result)

    @action(detail=True, methods=['get'], url_path='voucher-pdf')
    def voucher_pdf(self, request, pk=None):
        from django.http import HttpResponse
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        salary = self.get_object()
        pdf_bytes = universal_pdf_generator.generate_salary_voucher_pdf(salary)
        filename = format_dynamic_filename('salary_slip', salary.staff_name, salary.paid_month or salary.payment_date)
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response

    @action(detail=False, methods=['get'], url_path='ledger-pdf')
    def ledger_pdf(self, request):
        from django.http import HttpResponse
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        staff_filter = request.query_params.get('staff_name')
        if not staff_filter:
            return Response({'detail': 'staff_name query parameter is required.'}, status=400)

        ledger_resp = self.ledger(request)
        ledgers = ledger_resp.data
        employee_ledger = next((l for l in ledgers if l['staff_name'].strip().lower() == staff_filter.strip().lower()), None)
        if not employee_ledger:
            employee_ledger = next((l for l in ledgers if staff_filter.strip().lower() in l['staff_name'].strip().lower()), None)
        if not employee_ledger:
            return Response({'detail': f'No ledger found for staff "{staff_filter}"'}, status=404)

        pdf_bytes = universal_pdf_generator.generate_employee_ledger_pdf(employee_ledger)
        filename = format_dynamic_filename('employee_ledger', staff_filter, datetime.datetime.now().strftime('%Y%m%d'))
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response

class CashBookViewSet(viewsets.ModelViewSet):
    serializer_class = CashBookSerializer
    permission_classes = [IsAuthenticated, IsAdminRoleUser]

    def get_queryset(self):
        user = self.request.user
        qs = CashBook.objects.all()
        # Seed initial default books if none exist
        if not qs.exists():
            default_books = [
                {'name': 'Petty Cash', 'description': 'Daily office expenses and petty cash disbursements', 'color': '#10b981', 'icon': 'wallet'},
                {'name': 'Customer Payments', 'description': 'Client cash collections and direct receipts', 'color': '#3b82f6', 'icon': 'banknote'},
                {'name': 'General Expenses', 'description': 'Operational and business expenditure book', 'color': '#ef4444', 'icon': 'receipt'},
                {'name': 'September 2026', 'description': 'Current monthly consolidated cash ledger', 'color': '#8b5cf6', 'icon': 'calendar'},
            ]
            for b in default_books:
                CashBook.objects.create(
                    name=b['name'],
                    description=b['description'],
                    color=b['color'],
                    icon=b['icon'],
                    opening_balance=Decimal('0.00'),
                    created_by=user if user.is_authenticated else None
                )
            qs = CashBook.objects.all()

        show_archived = self.request.query_params.get('archived') == 'true'
        if not show_archived:
            qs = qs.filter(is_archived=False)
        return qs.order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='summary')
    def summary(self, request):
        books = self.get_queryset()
        total_in = Decimal('0.00')
        total_out = Decimal('0.00')
        total_opening = Decimal('0.00')

        for b in books:
            b_in = b.entries.filter(entry_type='in').exclude(approval_status='rejected').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
            b_out = b.entries.filter(entry_type='out').exclude(approval_status='rejected').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
            total_in += b_in
            total_out += b_out
            total_opening += b.opening_balance

        net_balance = total_opening + total_in - total_out
        return Response({
            'total_in': float(total_in),
            'total_out': float(total_out),
            'total_opening': float(total_opening),
            'net_balance': float(net_balance),
            'books_count': books.count()
        })

def compute_bank_delta(entry_type, transaction_type, remark, amount):
    tx = f"{transaction_type or ''} {remark or ''}".lower()
    if 'deposit' in tx:
        return amount  # Inflow into bank account
    elif 'withdrawal' in tx:
        return -amount # Outflow from bank account
    elif entry_type == 'in':
        return amount
    else:
        return -amount

class CashBookEntryViewSet(viewsets.ModelViewSet):
    serializer_class = CashBookEntrySerializer
    permission_classes = [IsAuthenticated, IsAdminRoleUser]

    def get_queryset(self):
        qs = CashBookEntry.objects.all().select_related('cashbook', 'created_by')
        book_id = self.request.query_params.get('cashbook')
        if book_id:
            qs = qs.filter(cashbook_id=book_id)

        entry_type = self.request.query_params.get('entry_type')
        if entry_type in ['in', 'out']:
            qs = qs.filter(entry_type=entry_type)

        category = self.request.query_params.get('category')
        if category and category != 'all':
            qs = qs.filter(category__iexact=category)

        payment_mode = self.request.query_params.get('payment_mode')
        if payment_mode and payment_mode != 'all':
            qs = qs.filter(payment_mode__iexact=payment_mode)

        tx_type = self.request.query_params.get('transaction_type')
        if tx_type and tx_type != 'all':
            qs = qs.filter(transaction_type__iexact=tx_type)

        bank_acc = self.request.query_params.get('bank_account')
        if bank_acc and bank_acc != 'all':
            qs = qs.filter(bank_account_id=bank_acc)

        petty_acc = self.request.query_params.get('petty_cash_account')
        if petty_acc and petty_acc != 'all':
            qs = qs.filter(petty_cash_account_id=petty_acc)

        start_date = self.request.query_params.get('start_date')
        if start_date:
            qs = qs.filter(date__gte=start_date)

        end_date = self.request.query_params.get('end_date')
        if end_date:
            qs = qs.filter(date__lte=end_date)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(remark__icontains=search) |
                Q(party_name__icontains=search) |
                Q(category__icontains=search) |
                Q(transaction_type__icontains=search) |
                Q(bank_account_name__icontains=search) |
                Q(petty_cash_account_name__icontains=search) |
                Q(reference_number__icontains=search)
            )

        return qs.order_by('date', 'time', 'created_at', 'id')

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        book_ids = set(queryset.values_list('cashbook_id', flat=True))
        running_map = {}
        for b_id in book_ids:
            if b_id:
                try:
                    book = CashBook.objects.get(id=b_id)
                    bal = Decimal(str(book.opening_balance or '0.00'))
                    all_cb_entries = CashBookEntry.objects.filter(cashbook_id=b_id).exclude(approval_status='rejected').order_by('date', 'time', 'created_at', 'id')
                    for e in all_cb_entries:
                        amt = Decimal(str(e.amount or '0.00'))
                        if e.entry_type == 'in':
                            bal += amt
                        else:
                            bal -= amt
                        running_map[e.id] = bal
                except CashBook.DoesNotExist:
                    pass

        bank_ids = set(queryset.values_list('bank_account_id', flat=True))
        for bk_id in bank_ids:
            if bk_id and bk_id not in running_map:
                try:
                    bank = BankAccount.objects.get(id=bk_id)
                    all_bk_entries = CashBookEntry.objects.filter(bank_account_id=bk_id).exclude(approval_status='rejected').order_by('date', 'time', 'created_at', 'id')
                    hist_in = all_bk_entries.filter(entry_type='in').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
                    hist_out = all_bk_entries.filter(entry_type='out').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
                    bal = (bank.balance or Decimal('0.00')) - (hist_in - hist_out)
                    for e in all_bk_entries:
                        amt = Decimal(str(e.amount or '0.00'))
                        delta = compute_bank_delta(e.entry_type, e.transaction_type, e.remark, amt)
                        bal += delta
                        if e.id not in running_map:
                            running_map[e.id] = bal
                except BankAccount.DoesNotExist:
                    pass

        page = self.paginate_queryset(queryset)
        if page is not None:
            for item in page:
                if item.id in running_map:
                    item.running_balance_val = running_map[item.id]
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        for item in queryset:
            if item.id in running_map:
                item.running_balance_val = running_map[item.id]
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

    def perform_create(self, serializer):
        entry = serializer.save(created_by=self.request.user)

        # 4.2 Automated Vendor Payment Routing
        if entry.entry_type == 'out':
            vendor = entry.vendor
            if not vendor and entry.party_name:
                vendor = Vendor.objects.filter(name__iexact=entry.party_name.strip()).first()
            if vendor:
                entry.vendor = vendor
                vp = VendorPayment.objects.create(
                    vendor=vendor,
                    amount=entry.amount,
                    payment_date=entry.date,
                    notes=f"Cashbook #{entry.cashbook.name}: {entry.remark or entry.party_name}".strip(),
                    created_by=self.request.user if self.request.user.is_authenticated else None
                )
                entry.vendor_payment = vp
                entry.save(update_fields=['vendor', 'vendor_payment'])

        if entry.bank_account:
            bank = entry.bank_account
            amt = Decimal(str(entry.amount))
            delta = compute_bank_delta(entry.entry_type, entry.transaction_type, entry.remark, amt)
            bank.balance = (bank.balance or Decimal('0.00')) + delta
            bank.save(update_fields=['balance'])

        if entry.petty_cash_account:
            pca = entry.petty_cash_account
            amt = Decimal(str(entry.amount))
            if entry.entry_type == 'in':
                # 4.1 Petty Cash Approval Workflow: Check if current user is adding cash to someone else's petty cash account
                account_owner = pca.owner
                if not account_owner and pca.created_by:
                    account_owner = pca.created_by
                if not account_owner and pca.holder_name:
                    from django.contrib.auth import get_user_model
                    UserModel = get_user_model()
                    account_owner = UserModel.objects.filter(
                        Q(first_name__iexact=pca.holder_name.strip()) |
                        Q(username__iexact=pca.holder_name.strip())
                    ).first()

                current_user = self.request.user if self.request.user.is_authenticated else None
                is_other_person = bool(
                    account_owner and current_user and account_owner.id != current_user.id
                )

                if is_other_person:
                    entry.approval_status = 'pending'
                    entry.save(update_fields=['approval_status'])
                    # Held in pending: do NOT credit pca.balance yet!
                    actor_name = current_user.get_full_name() or current_user.username
                    Notification.objects.create(
                        recipient=account_owner,
                        actor=current_user,
                        notification_type='petty_cash_approval',
                        title=f"Petty Cash Deposit: {entry.amount} {pca.currency}",
                        message=f"{actor_name} added {entry.amount} {pca.currency} to your petty cash account ({pca.name}). Please review and approve with 'OK'.",
                        action_type='petty_cash_approval',
                        action_data={
                            'entry_id': entry.id,
                            'cashbook_id': entry.cashbook_id,
                            'cashbook_name': entry.cashbook.name,
                            'account_id': pca.id,
                            'account_name': pca.name,
                            'amount': str(entry.amount),
                            'currency': pca.currency,
                            'date': str(entry.date),
                            'party_name': entry.party_name,
                            'remark': entry.remark
                        }
                    )
                else:
                    entry.approval_status = 'approved'
                    entry.save(update_fields=['approval_status'])
                    pca.balance = (pca.balance or Decimal('0.00')) + amt
                    pca.save(update_fields=['balance'])
            elif entry.entry_type == 'out':
                pca.balance = (pca.balance or Decimal('0.00')) - amt
                pca.save(update_fields=['balance'])

    def perform_update(self, serializer):
        old_instance = self.get_object()
        old_bank = old_instance.bank_account
        old_pca = old_instance.petty_cash_account
        old_entry_type = old_instance.entry_type
        old_amount = Decimal(str(old_instance.amount))
        old_status = old_instance.approval_status

        if old_bank:
            old_delta = compute_bank_delta(old_entry_type, old_instance.transaction_type, old_instance.remark, old_amount)
            old_bank.balance = (old_bank.balance or Decimal('0.00')) - old_delta
            old_bank.save(update_fields=['balance'])

        if old_pca:
            if old_entry_type == 'in':
                if old_status == 'approved':
                    old_pca.balance = (old_pca.balance or Decimal('0.00')) - old_amount
                    old_pca.save(update_fields=['balance'])
            elif old_entry_type == 'out':
                old_pca.balance = (old_pca.balance or Decimal('0.00')) + old_amount
                old_pca.save(update_fields=['balance'])

        new_instance = serializer.save()

        # Synchronize automated VendorPayment
        if new_instance.entry_type == 'out':
            vendor = new_instance.vendor
            if not vendor and new_instance.party_name:
                vendor = Vendor.objects.filter(name__iexact=new_instance.party_name.strip()).first()
            if vendor:
                new_instance.vendor = vendor
                if new_instance.vendor_payment:
                    vp = new_instance.vendor_payment
                    vp.vendor = vendor
                    vp.amount = new_instance.amount
                    vp.payment_date = new_instance.date
                    vp.notes = f"Cashbook #{new_instance.cashbook.name}: {new_instance.remark or new_instance.party_name}".strip()
                    vp.save()
                else:
                    vp = VendorPayment.objects.create(
                        vendor=vendor,
                        amount=new_instance.amount,
                        payment_date=new_instance.date,
                        notes=f"Cashbook #{new_instance.cashbook.name}: {new_instance.remark or new_instance.party_name}".strip(),
                        created_by=self.request.user if self.request.user.is_authenticated else None
                    )
                    new_instance.vendor_payment = vp
                new_instance.save(update_fields=['vendor', 'vendor_payment'])
            elif new_instance.vendor_payment:
                new_instance.vendor_payment.delete()
                new_instance.vendor_payment = None
                new_instance.save(update_fields=['vendor_payment'])
        elif new_instance.vendor_payment:
            new_instance.vendor_payment.delete()
            new_instance.vendor_payment = None
            new_instance.save(update_fields=['vendor_payment'])

        if new_instance.bank_account:
            bank = new_instance.bank_account
            amt = Decimal(str(new_instance.amount))
            new_delta = compute_bank_delta(new_instance.entry_type, new_instance.transaction_type, new_instance.remark, amt)
            bank.balance = (bank.balance or Decimal('0.00')) + new_delta
            bank.save(update_fields=['balance'])

        if new_instance.petty_cash_account:
            pca = new_instance.petty_cash_account
            amt = Decimal(str(new_instance.amount))
            if new_instance.entry_type == 'in':
                if new_instance.approval_status == 'approved':
                    pca.balance = (pca.balance or Decimal('0.00')) + amt
                    pca.save(update_fields=['balance'])
            elif new_instance.entry_type == 'out':
                pca.balance = (pca.balance or Decimal('0.00')) - amt
                pca.save(update_fields=['balance'])

    def perform_destroy(self, instance):
        if instance.vendor_payment:
            try:
                instance.vendor_payment.delete()
            except Exception:
                pass
        if instance.bank_account:
            bank = instance.bank_account
            amt = Decimal(str(instance.amount))
            delta = compute_bank_delta(instance.entry_type, instance.transaction_type, instance.remark, amt)
            bank.balance = (bank.balance or Decimal('0.00')) - delta
            bank.save(update_fields=['balance'])
        if instance.petty_cash_account:
            pca = instance.petty_cash_account
            amt = Decimal(str(instance.amount))
            if instance.entry_type == 'in':
                if instance.approval_status == 'approved':
                    pca.balance = (pca.balance or Decimal('0.00')) - amt
                    pca.save(update_fields=['balance'])
            elif instance.entry_type == 'out':
                pca.balance = (pca.balance or Decimal('0.00')) + amt
                pca.save(update_fields=['balance'])
        instance.delete()

    @action(detail=True, methods=['post'], url_path='approve')
    def approve_entry(self, request, pk=None):
        entry = self.get_object()
        if entry.approval_status == 'approved':
            return Response({'detail': 'Entry is already approved.'})
        pca = entry.petty_cash_account
        if not pca:
            return Response({'detail': 'Entry has no linked petty cash account.'}, status=status.HTTP_400_BAD_REQUEST)

        # Check authorization: user must be the account owner, or admin
        account_owner = pca.owner or pca.created_by
        if account_owner and request.user.id != account_owner.id and not is_admin_user(request.user):
            return Response({'detail': 'Only the petty cash account owner can approve this addition.'}, status=status.HTTP_403_FORBIDDEN)

        entry.approval_status = 'approved'
        entry.approved_by = request.user
        entry.approved_at = timezone.now()
        entry.save(update_fields=['approval_status', 'approved_by', 'approved_at'])

        # Now credit the balance
        amt = Decimal(str(entry.amount))
        pca.balance = (pca.balance or Decimal('0.00')) + amt
        pca.save(update_fields=['balance'])

        # Update any notifications for this entry
        Notification.objects.filter(
            notification_type='petty_cash_approval',
            action_data__entry_id=entry.id
        ).update(is_read=True, action_taken='approved')

        return Response({
            'detail': 'Petty cash addition approved successfully.',
            'entry': CashBookEntrySerializer(entry).data,
            'account_balance': float(pca.balance)
        })

    @action(detail=True, methods=['post'], url_path='reject')
    def reject_entry(self, request, pk=None):
        entry = self.get_object()
        if entry.approval_status == 'rejected':
            return Response({'detail': 'Entry is already rejected.'})
        pca = entry.petty_cash_account
        account_owner = pca.owner or pca.created_by if pca else None
        if account_owner and request.user.id != account_owner.id and not is_admin_user(request.user):
            return Response({'detail': 'Only the petty cash account owner can reject this addition.'}, status=status.HTTP_403_FORBIDDEN)

        entry.approval_status = 'rejected'
        entry.approved_by = request.user
        entry.approved_at = timezone.now()
        entry.save(update_fields=['approval_status', 'approved_by', 'approved_at'])

        Notification.objects.filter(
            notification_type='petty_cash_approval',
            action_data__entry_id=entry.id
        ).update(is_read=True, action_taken='rejected')

        return Response({
            'detail': 'Petty cash addition rejected.',
            'entry': CashBookEntrySerializer(entry).data
        })

    @action(detail=False, methods=['get'], url_path='ledger')
    def ledger(self, request):
        book_id = request.query_params.get('cashbook')
        if not book_id:
            return Response({'error': 'cashbook query parameter is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            book = CashBook.objects.get(pk=book_id)
        except CashBook.DoesNotExist:
            return Response({'error': 'CashBook not found'}, status=status.HTTP_404_NOT_FOUND)

        # Precompute chronological running balance map for ALL entries of this book
        all_book_entries = CashBookEntry.objects.filter(cashbook_id=book_id).exclude(approval_status='rejected').order_by('date', 'time', 'created_at', 'id')
        running_map = {}
        curr_bal = Decimal(str(book.opening_balance or 0))
        for e in all_book_entries:
            amt = e.amount
            if e.entry_type == 'in':
                curr_bal += amt
            else:
                curr_bal -= amt
            running_map[e.id] = curr_bal

        entries_qs = self.get_queryset().filter(cashbook_id=book_id).exclude(approval_status='rejected')
        
        total_in = Decimal('0.00')
        total_out = Decimal('0.00')
        ledger_entries = []

        for e in entries_qs:
            amt = e.amount
            if e.entry_type == 'in':
                total_in += amt
            else:
                total_out += amt

            ledger_entries.append({
                'id': e.id,
                'cashbook': e.cashbook_id,
                'cashbook_name': book.name,
                'entry_type': e.entry_type,
                'amount': float(amt),
                'date': str(e.date),
                'time': str(e.time) if e.time else None,
                'category': e.category,
                'remark': e.remark,
                'party_name': e.party_name,
                'payment_mode': e.payment_mode,
                'transaction_type': e.transaction_type,
                'bank_account': e.bank_account_id,
                'bank_account_name': e.bank_account_name,
                'petty_cash_account': e.petty_cash_account_id,
                'petty_cash_account_name': e.petty_cash_account_name,
                'reference_number': e.reference_number,
                'custom_fields': e.custom_fields or {},
                'running_balance': float(running_map.get(e.id, 0.0)),
                'created_by_name': e.created_by.username if e.created_by else 'System'
            })

        return Response({
            'cashbook': {
                'id': book.id,
                'name': book.name,
                'description': book.description,
                'color': book.color,
                'icon': book.icon,
                'currency': book.currency,
                'opening_balance': float(book.opening_balance)
            },
            'total_in': float(total_in),
            'total_out': float(total_out),
            'net_balance': float(curr_bal),
            'entries_count': len(ledger_entries),
            'entries': list(reversed(ledger_entries))
        })

    @action(detail=False, methods=['get'], url_path='bank-flow')
    def bank_flow(self, request):
        entries = CashBookEntry.objects.filter(
            Q(bank_account__isnull=False) | Q(payment_mode__iexact='Bank Transfer')
        ).select_related('cashbook', 'bank_account', 'created_by')

        start_date = request.query_params.get('start_date')
        if start_date:
            entries = entries.filter(date__gte=start_date)

        end_date = request.query_params.get('end_date')
        if end_date:
            entries = entries.filter(date__lte=end_date)

        bank_acc_id = request.query_params.get('bank_account')
        if bank_acc_id and bank_acc_id not in ['all', 'All']:
            entries = entries.filter(bank_account_id=bank_acc_id)

        flow_type = request.query_params.get('flow_type')
        if flow_type in ['deposit', 'in']:
            entries = entries.filter(entry_type='in')
        elif flow_type in ['withdrawal', 'out']:
            entries = entries.filter(entry_type='out')

        search = request.query_params.get('search')
        if search:
            entries = entries.filter(
                Q(remark__icontains=search) |
                Q(party_name__icontains=search) |
                Q(category__icontains=search) |
                Q(bank_account_name__icontains=search) |
                Q(reference_number__icontains=search) |
                Q(cashbook__name__icontains=search)
            )

        total_bank_deposits = entries.filter(entry_type='in').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        total_bank_withdrawals = entries.filter(entry_type='out').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        net_bank_flow = total_bank_deposits - total_bank_withdrawals

        banks = BankAccount.objects.all()
        bank_stats = []
        for b in banks:
            b_entries = CashBookEntry.objects.filter(bank_account_id=b.id)
            b_deposits = b_entries.filter(entry_type='in').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
            b_withdrawals = b_entries.filter(entry_type='out').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
            bank_stats.append({
                'id': b.id,
                'bank_name': b.bank_name,
                'account_number': b.account_number,
                'balance': float(b.balance or 0),
                'currency': b.currency,
                'status': b.status,
                'total_deposits': float(b_deposits),
                'total_withdrawals': float(b_withdrawals),
                'net_flow': float(b_deposits - b_withdrawals),
                'transaction_count': b_entries.count()
            })

        total_bank_reserves = banks.filter(status='Active').aggregate(tot=Coalesce(Sum('balance'), Decimal('0'), output_field=DecimalField()))['tot']
        total_petty_cash_reserves = PettyCashAccount.objects.filter(status='Active').aggregate(tot=Coalesce(Sum('balance'), Decimal('0'), output_field=DecimalField()))['tot']

        ordered_entries = entries.order_by('-date', '-time', '-created_at', '-id')
        transaction_list = []
        for e in ordered_entries:
            transaction_list.append({
                'id': e.id,
                'cashbook': e.cashbook_id,
                'cashbook_name': e.cashbook.name if e.cashbook else 'Unassigned',
                'entry_type': e.entry_type,
                'flow_direction': 'Bank Deposit / Receipt' if e.entry_type == 'in' else 'Bank Payment / Outflow',
                'amount': float(e.amount),
                'date': str(e.date),
                'time': str(e.time) if e.time else None,
                'category': e.category,
                'remark': e.remark,
                'party_name': e.party_name,
                'payment_mode': e.payment_mode,
                'transaction_type': e.transaction_type,
                'bank_account': e.bank_account_id,
                'bank_account_name': e.bank_account_name or (e.bank_account.bank_name if e.bank_account else 'Unspecified Bank'),
                'bank_account_number': e.bank_account.account_number if e.bank_account else '',
                'petty_cash_account': e.petty_cash_account_id,
                'petty_cash_account_name': e.petty_cash_account_name or (e.petty_cash_account.name if e.petty_cash_account else ''),
                'reference_number': e.reference_number,
                'custom_fields': e.custom_fields or {},
                'created_by_name': e.created_by.username if e.created_by else 'System'
            })

        return Response({
            'total_bank_deposits': float(total_bank_deposits),
            'total_bank_withdrawals': float(total_bank_withdrawals),
            'net_bank_flow': float(net_bank_flow),
            'total_transactions': entries.count(),
            'total_bank_reserves': float(total_bank_reserves),
            'total_petty_cash_reserves': float(total_petty_cash_reserves),
            'banks_summary': bank_stats,
            'transactions': transaction_list
        })

    @action(detail=False, methods=['get'], url_path='ledger-pdf')
    def ledger_pdf(self, request):
        from django.http import HttpResponse
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename

        resp = self.ledger(request)
        if resp.status_code != 200:
            return resp

        data = resp.data
        book_data = data['cashbook']
        summary = {
            'opening_balance': book_data.get('opening_balance', 0),
            'total_in': data.get('total_in', 0),
            'total_out': data.get('total_out', 0),
            'net_balance': data.get('net_balance', 0),
        }
        entries = list(reversed(data.get('entries', [])))
        filters = {
            'start_date': request.query_params.get('start_date'),
            'end_date': request.query_params.get('end_date')
        }

        pdf_bytes = universal_pdf_generator.generate_cashbook_ledger_pdf(
            book_data=book_data,
            summary=summary,
            entries=entries,
            filters=filters
        )

        s_date = filters.get('start_date')
        e_date = filters.get('end_date')
        filename = format_dynamic_filename('cashbook', book_data.get('name', 'cashbook'), s_date, 'to' if s_date and e_date else None, e_date or datetime.datetime.now().strftime('%Y%m%d'))
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response

    @action(detail=False, methods=['get'], url_path='bank-flow-pdf')
    def bank_flow_pdf(self, request):
        from django.http import HttpResponse
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename

        resp = self.bank_flow(request)
        if resp.status_code != 200:
            return resp

        data = resp.data
        summary = {
            'total_inflows': data.get('total_bank_deposits', 0),
            'total_outflows': data.get('total_bank_withdrawals', 0),
            'net_flow': data.get('net_bank_flow', 0),
            'total_transactions': data.get('total_transactions', len(data.get('transactions', []))),
        }
        transactions = data.get('transactions', [])
        filters = {
            'start_date': request.query_params.get('start_date'),
            'end_date': request.query_params.get('end_date')
        }

        pdf_bytes = universal_pdf_generator.generate_cashbook_bank_flow_pdf(
            summary=summary,
            transactions=transactions,
            filters=filters
        )

        s_date = filters.get('start_date')
        e_date = filters.get('end_date')
        filename = format_dynamic_filename('cashbook_bank_flow', s_date, 'to' if s_date and e_date else None, e_date or datetime.datetime.now().strftime('%Y%m%d'))
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response


class StaffTimesheetViewSet(viewsets.ModelViewSet):
    serializer_class = StaffTimesheetSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = None

    def get_queryset(self):
        # Seed reference dataset matching user's reference screenshot if none exist
        if not StaffTimesheet.objects.exists():
            from accounts.models import CustomUser
            default_user = CustomUser.objects.filter(username='mustaq').first() or CustomUser.objects.first()
            s_name = (f"{default_user.first_name} {default_user.last_name}".strip() or default_user.username) if default_user else 'mustaq'
            
            sample_entries = [
                {'date': '2026-08-06', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-07', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-08', 'in_time': '9:00:00 AM', 'lunch_time': '', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 500, 'overtime_hours': 3, 'overtime_text': '3hr', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-09', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-10', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-11', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-13', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 100, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-14', 'in_time': '', 'lunch_time': '', 'out_time': '', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': True},
                {'date': '2026-08-15', 'in_time': '9:00:00 AM', 'lunch_time': '', 'out_time': '11:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 4, 'overtime_text': '4HR', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-16', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '1:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 3, 'overtime_text': '3HR', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-17', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '1:00:00 PM', 'debit': 0, 'credit': 100, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-18', 'in_time': '9:00:00 AM', 'lunch_time': '', 'out_time': '12:00:00 AM', 'debit': 0, 'credit': 0, 'overtime_hours': 3, 'overtime_text': '3hr', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-19', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '1:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-20', 'in_time': '9:00:00 AM', 'lunch_time': '', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 3, 'overtime_text': '3hr', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-21', 'in_time': '', 'lunch_time': '', 'out_time': '', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': True},
                {'date': '2026-08-22', 'in_time': '9:00:00 AM', 'lunch_time': '', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-23', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-24', 'in_time': '4:00:00 PM', 'lunch_time': '', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-25', 'in_time': '9:00:00 AM', 'lunch_time': '2:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 1, 'overtime_text': '1 HR', 'ot_details': 'SPACE CRAFT WORK', 'is_off_day': False},
                {'date': '2026-08-26', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 100, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-27', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-28', 'in_time': '', 'lunch_time': '2:00:00 PM', 'out_time': '5:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 3, 'overtime_text': '3HR', 'ot_details': 'NISAM MINISTRY OF CULTURE', 'is_off_day': True},
                {'date': '2026-08-29', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-08-30', 'in_time': '9:00:00 AM', 'lunch_time': '', 'out_time': '2:00:00 AM', 'debit': 0, 'credit': 0, 'overtime_hours': 7, 'overtime_text': '7HR', 'ot_details': 'NISAM MINISTRY OF CULTURE', 'is_off_day': False},
                {'date': '2026-08-31', 'in_time': '9:00:00 AM', 'lunch_time': '', 'out_time': '4:00:00 AM', 'debit': 0, 'credit': 0, 'overtime_hours': 9, 'overtime_text': '9HR', 'ot_details': 'popup setting&moc die cut', 'is_off_day': False},
                {'date': '2026-09-01', 'in_time': '9:00:00 AM', 'lunch_time': '2:00:00 PM', 'out_time': '12:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 3, 'overtime_text': '3hr', 'ot_details': 'banner print & moc die cut', 'is_off_day': False},
                {'date': '2026-09-02', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
                {'date': '2026-09-03', 'in_time': '9:00:00 AM', 'lunch_time': '2:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 1, 'overtime_text': '1 HR', 'ot_details': 'ASHRAF FOREX SETTING', 'is_off_day': False},
                {'date': '2026-09-04', 'in_time': '', 'lunch_time': '', 'out_time': '', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': True},
                {'date': '2026-09-05', 'in_time': '9:00:00 AM', 'lunch_time': '1:00:00 PM', 'out_time': '10:00:00 PM', 'debit': 0, 'credit': 0, 'overtime_hours': 0, 'overtime_text': '', 'ot_details': '', 'is_off_day': False},
            ]
            for se in sample_entries:
                StaffTimesheet.objects.create(
                    user=default_user,
                    staff_name=s_name,
                    created_by=self.request.user if self.request.user.is_authenticated else None,
                    **se
                )

        qs = StaffTimesheet.objects.all().select_related('user', 'created_by')
        
        staff_name = self.request.query_params.get('staff_name')
        if staff_name and staff_name != 'All':
            qs = qs.filter(Q(staff_name__iexact=staff_name) | Q(user__username__iexact=staff_name))

        user_id = self.request.query_params.get('user_id')
        if user_id and user_id != 'All':
            qs = qs.filter(user_id=user_id)

        start_date = self.request.query_params.get('start_date')
        if start_date:
            qs = qs.filter(date__gte=start_date)

        end_date = self.request.query_params.get('end_date')
        if end_date:
            qs = qs.filter(date__lte=end_date)

        month_str = self.request.query_params.get('month')
        if month_str and month_str != 'All':
            # e.g., "August 2026" or "2026-08"
            dt = None
            try:
                dt = datetime.datetime.strptime(month_str, '%B %Y')
            except ValueError:
                try:
                    dt = datetime.datetime.strptime(month_str, '%Y-%m')
                except ValueError:
                    pass
            if dt:
                qs = qs.filter(date__year=dt.year, date__month=dt.month)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(staff_name__icontains=search) |
                Q(ot_details__icontains=search) |
                Q(overtime_text__icontains=search)
            )

        ordering = self.request.query_params.get('ordering', '-date')
        if ordering == 'asc':
            return qs.order_by('date', 'created_at', 'id')
        return qs.order_by('-date', '-created_at', '-id')

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='staff-users')
    def staff_users(self, request):
        """
        Returns list of database users for staff selection.
        """
        from accounts.models import CustomUser
        users = CustomUser.objects.all().order_by('username')
        data = []
        for u in users:
            full_name = f"{u.first_name} {u.last_name}".strip()
            data.append({
                'id': u.id,
                'username': u.username,
                'full_name': full_name or u.username,
                'email': u.email,
                'role': u.role
            })
        return Response(data)

    @action(detail=False, methods=['post'], url_path='generate-month')
    def generate_month(self, request):
        """
        Bulk generate 1 month (28-31 days) of timesheet attendance entries for a staff member.
        Parameters in request.data:
        - staff_name (str)
        - user_id (int, optional)
        - month (str like 'September 2026' or '2026-09' or int 1-12)
        - year (int, optional)
        - in_time (str, default '9:00:00 AM')
        - lunch_time (str, default '1:00:00 PM')
        - out_time (str, default '10:00:00 PM')
        - off_days (list of int, default [4] which is Friday)
        - overwrite_existing (bool, default False)
        """
        import calendar
        from accounts.models import CustomUser

        staff_name = request.data.get('staff_name', '').strip()
        user_id = request.data.get('user_id')
        user = None
        if user_id:
            try:
                user = CustomUser.objects.filter(id=int(user_id)).first()
            except (ValueError, TypeError):
                pass

        if not staff_name and user:
            staff_name = f"{user.first_name} {user.last_name}".strip() or user.username

        if not staff_name:
            return Response({'error': 'Staff member name is required.'}, status=status.HTTP_400_BAD_REQUEST)

        # Parse year and month
        month_raw = request.data.get('month')
        year_raw = request.data.get('year')

        target_year = None
        target_month = None

        if isinstance(month_raw, str):
            try:
                dt = datetime.datetime.strptime(month_raw.strip(), '%B %Y')
                target_year = dt.year
                target_month = dt.month
            except ValueError:
                try:
                    dt = datetime.datetime.strptime(month_raw.strip(), '%Y-%m')
                    target_year = dt.year
                    target_month = dt.month
                except ValueError:
                    pass

        if not target_month and month_raw is not None:
            try:
                target_month = int(month_raw)
            except (ValueError, TypeError):
                pass

        if not target_year and year_raw is not None:
            try:
                target_year = int(year_raw)
            except (ValueError, TypeError):
                pass

        now = datetime.datetime.now()
        if not target_year:
            target_year = now.year
        if not target_month or target_month < 1 or target_month > 12:
            target_month = now.month

        # Standard shift timings
        in_time = request.data.get('in_time', '9:00:00 AM')
        lunch_time = request.data.get('lunch_time', '1:00:00 PM')
        out_time = request.data.get('out_time', '10:00:00 PM')

        # Off days: default Friday (weekday 4). Can be int or list of ints.
        off_days = request.data.get('off_days', [4])
        if isinstance(off_days, int):
            off_days = [off_days]
        elif not isinstance(off_days, list):
            off_days = [4]

        overwrite_existing = bool(request.data.get('overwrite_existing', False))

        _, num_days = calendar.monthrange(target_year, target_month)
        
        created_count = 0
        updated_count = 0
        skipped_count = 0

        for day in range(1, num_days + 1):
            entry_date = datetime.date(target_year, target_month, day)
            is_off = entry_date.weekday() in off_days

            existing_qs = StaffTimesheet.objects.filter(date=entry_date)
            if user:
                existing = existing_qs.filter(Q(user=user) | Q(staff_name__iexact=staff_name)).first()
            else:
                existing = existing_qs.filter(staff_name__iexact=staff_name).first()

            day_in = '' if is_off else in_time
            day_lunch = '' if is_off else lunch_time
            day_out = '' if is_off else out_time

            if existing:
                if overwrite_existing:
                    existing.in_time = day_in
                    existing.lunch_time = day_lunch
                    existing.out_time = day_out
                    existing.is_off_day = is_off
                    existing.user = user or existing.user
                    existing.staff_name = staff_name
                    existing.save()
                    updated_count += 1
                else:
                    skipped_count += 1
            else:
                StaffTimesheet.objects.create(
                    user=user,
                    staff_name=staff_name,
                    date=entry_date,
                    in_time=day_in,
                    lunch_time=day_lunch,
                    out_time=day_out,
                    debit=0,
                    credit=0,
                    overtime_hours=0,
                    overtime_text='',
                    ot_details='',
                    is_off_day=is_off,
                    created_by=request.user if request.user.is_authenticated else None
                )
                created_count += 1

        month_display = datetime.date(target_year, target_month, 1).strftime('%B %Y')
        return Response({
            'message': f'Timesheet for {month_display} ({num_days} days) generated successfully.',
            'month': month_display,
            'year': target_year,
            'month_num': target_month,
            'num_days': num_days,
            'created_count': created_count,
            'updated_count': updated_count,
            'skipped_count': skipped_count,
            'staff_name': staff_name,
            'user_id': user.id if user else None
        }, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='pdf')
    def pdf(self, request):
        from django.http import HttpResponse
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        qs = self.filter_queryset(self.get_queryset())
        filters = {
            'start_date': request.query_params.get('start_date'),
            'end_date': request.query_params.get('end_date'),
            'staff_name': request.query_params.get('staff_name'),
            'month': request.query_params.get('month')
        }
        pdf_bytes = universal_pdf_generator.generate_timesheet_report_pdf(list(qs), filters=filters)
        staff_str = filters.get('staff_name') or 'all_staff'
        month_or_period = filters.get('month') or (f"{filters.get('start_date')}_to_{filters.get('end_date')}" if filters.get('start_date') else datetime.datetime.now().strftime('%Y%m%d'))
        filename = format_dynamic_filename('timesheet', staff_str, month_or_period)
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response


class BankAccountViewSet(viewsets.ModelViewSet):
    serializer_class = BankAccountSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = BankAccount.objects.all().select_related('created_by')
        # Seed default accounts if none exist
        if not qs.exists():
            default_banks = [
                {
                    'bank_name': 'Al Rajhi Bank',
                    'account_number': 'SA4580000201608010123456',
                    'account_holder_name': 'Arab Season Enterprise LLC',
                    'iban': 'SA4580000201608010123456',
                    'branch_name': 'Main Branch, Riyadh',
                    'balance': Decimal('150000.00'),
                    'currency': 'SAR',
                    'status': 'Active',
                    'notes': 'Primary operational business account'
                },
                {
                    'bank_name': 'SNB AlAhli (National Commercial Bank)',
                    'account_number': 'SA1210000001234567890123',
                    'account_holder_name': 'Arab Season Enterprise LLC',
                    'iban': 'SA1210000001234567890123',
                    'branch_name': 'Olaya Branch',
                    'balance': Decimal('85400.00'),
                    'currency': 'SAR',
                    'status': 'Active',
                    'notes': 'Vendor payments & payroll reserve'
                },
                {
                    'bank_name': 'Riyad Bank',
                    'account_number': 'SA9820000009876543210987',
                    'account_holder_name': 'Arab Season Enterprise LLC',
                    'iban': 'SA9820000009876543210987',
                    'branch_name': 'King Fahd Road',
                    'balance': Decimal('42500.00'),
                    'currency': 'SAR',
                    'status': 'Active',
                    'notes': 'Tax and VAT reserve account'
                }
            ]
            for b in default_banks:
                BankAccount.objects.create(
                    created_by=self.request.user if self.request.user.is_authenticated else None,
                    **b
                )
            qs = BankAccount.objects.all().select_related('created_by')

        status_param = self.request.query_params.get('status')
        if status_param and status_param != 'All':
            qs = qs.filter(status__iexact=status_param)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(bank_name__icontains=search) |
                Q(account_number__icontains=search) |
                Q(account_holder_name__icontains=search) |
                Q(iban__icontains=search) |
                Q(branch_name__icontains=search)
            )
        return qs.order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='summary')
    def summary(self, request):
        qs = BankAccount.objects.all()
        total_balance = qs.aggregate(tot=Coalesce(Sum('balance'), Decimal('0'), output_field=DecimalField()))['tot']
        active_count = qs.filter(status='Active').count()
        total_count = qs.count()
        return Response({
            'total_balance': float(total_balance),
            'active_accounts': active_count,
            'total_accounts': total_count,
            'currency': 'SAR'
        })

    @action(detail=True, methods=['get'], url_path='statement')
    def statement(self, request, pk=None):
        bank = self.get_object()

        # All historical transactions for this bank account
        all_entries = CashBookEntry.objects.filter(bank_account=bank).order_by('date', 'time', 'created_at', 'id')

        # Compute true opening balance before all recorded transactions
        hist_in = all_entries.filter(entry_type='in').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        hist_out = all_entries.filter(entry_type='out').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        initial_balance = (bank.balance or Decimal('0.00')) - (hist_in - hist_out)

        # Filters
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')
        flow_type = request.query_params.get('flow_type')
        search = request.query_params.get('search')

        # Calculate opening balance for the chosen date period
        if start_date:
            prior_entries = all_entries.filter(date__lt=start_date)
            prior_in = prior_entries.filter(entry_type='in').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
            prior_out = prior_entries.filter(entry_type='out').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
            period_opening_balance = initial_balance + (prior_in - prior_out)
        else:
            period_opening_balance = initial_balance

        # Filter entries for the period
        period_entries = all_entries
        if start_date:
            period_entries = period_entries.filter(date__gte=start_date)
        if end_date:
            period_entries = period_entries.filter(date__lte=end_date)

        period_inflows = period_entries.filter(entry_type='in').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        period_outflows = period_entries.filter(entry_type='out').aggregate(tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField()))['tot']
        period_net = period_inflows - period_outflows
        period_closing_balance = period_opening_balance + period_net

        # Compute running balances sequentially
        running_bal = period_opening_balance
        statement_transactions = []
        for e in period_entries.select_related('cashbook', 'created_by'):
            amt = Decimal(str(e.amount))
            is_credit = (e.entry_type == 'in')
            if is_credit:
                running_bal += amt
                credit_val = amt
                debit_val = Decimal('0.00')
            else:
                running_bal -= amt
                credit_val = Decimal('0.00')
                debit_val = amt

            statement_transactions.append({
                'id': e.id,
                'date': str(e.date),
                'time': str(e.time) if e.time else None,
                'reference_number': e.reference_number or f"TX-B{bank.id}-{e.id:04d}",
                'remark': e.remark or 'Bank Settlement',
                'party_name': e.party_name or 'Direct Transaction',
                'category': e.category or 'General',
                'payment_mode': e.payment_mode,
                'transaction_type': e.transaction_type,
                'entry_type': e.entry_type,
                'credit': float(credit_val),
                'debit': float(debit_val),
                'running_balance': float(running_bal),
                'cashbook_id': e.cashbook_id,
                'cashbook_name': e.cashbook.name if e.cashbook else 'Cashbook',
                'created_by_name': e.created_by.username if e.created_by else 'System'
            })

        # Apply search and flow_type filters to displayed transactions
        filtered_list = []
        for tx in statement_transactions:
            if flow_type in ['in', 'credit', 'deposit'] and tx['entry_type'] != 'in':
                continue
            if flow_type in ['out', 'debit', 'withdrawal'] and tx['entry_type'] != 'out':
                continue
            if search:
                s_lower = search.lower()
                matches = (
                    s_lower in tx['remark'].lower() or
                    s_lower in tx['party_name'].lower() or
                    s_lower in tx['category'].lower() or
                    s_lower in tx['reference_number'].lower() or
                    s_lower in tx['cashbook_name'].lower()
                )
                if not matches:
                    continue
            filtered_list.append(tx)

        return Response({
            'bank': {
                'id': bank.id,
                'bank_name': bank.bank_name,
                'account_number': bank.account_number,
                'account_holder_name': bank.account_holder_name or 'Arab Season Enterprise LLC',
                'iban': bank.iban,
                'branch_name': bank.branch_name,
                'balance': float(bank.balance or 0),
                'currency': bank.currency or 'SAR',
                'status': bank.status,
                'notes': bank.notes
            },
            'filters': {
                'start_date': start_date,
                'end_date': end_date,
                'flow_type': flow_type,
                'search': search
            },
            'summary': {
                'initial_balance': float(initial_balance),
                'opening_balance': float(period_opening_balance),
                'total_credits': float(period_inflows),
                'total_debits': float(period_outflows),
                'net_change': float(period_net),
                'closing_balance': float(period_closing_balance),
                'transactions_count': period_entries.count(),
                'filtered_count': len(filtered_list)
            },
            'transactions': filtered_list
        })

    @action(detail=True, methods=['get'], url_path='statement-pdf')
    def statement_pdf(self, request, pk=None):
        from django.http import HttpResponse
        from rest_framework_simplejwt.authentication import JWTAuthentication
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename

        # Optional query param token authentication for direct browser links
        if not request.user or not request.user.is_authenticated:
            query_token = request.query_params.get('token')
            if query_token:
                try:
                    jwt_auth = JWTAuthentication()
                    validated_token = jwt_auth.get_validated_token(query_token)
                    request.user = jwt_auth.get_user(validated_token)
                except Exception:
                    pass

        stmt_resp = self.statement(request, pk=pk)
        if stmt_resp.status_code != 200:
            return stmt_resp

        data = stmt_resp.data
        bank = self.get_object()
        summary = data['summary']
        transactions = data['transactions']
        filters = data['filters']

        sort_order = request.query_params.get('sort', 'asc')
        if sort_order == 'desc':
            transactions = list(reversed(transactions))

        pdf_bytes = universal_pdf_generator.generate_bank_statement_pdf(
            bank=bank,
            summary=summary,
            transactions=transactions,
            filters=filters
        )

        s_date = filters.get('start_date')
        e_date = filters.get('end_date')
        filename = format_dynamic_filename('bank_statement', bank.bank_name, s_date, 'to' if s_date and e_date else None, e_date or datetime.datetime.now().strftime('%Y%m%d'))

        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response


class PettyCashAccountViewSet(viewsets.ModelViewSet):
    serializer_class = PettyCashAccountSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = PettyCashAccount.objects.all().select_related('created_by')
        # Seed default accounts if none exist
        if not qs.exists():
            default_accounts = [
                {
                    'name': 'Nizam Petty Cash',
                    'holder_name': 'Nizam',
                    'balance': Decimal('0.00'),
                    'currency': 'SAR',
                    'status': 'Active',
                    'notes': 'Custody account for Nizam'
                },
                {
                    'name': 'Shuhaib Petty Cash',
                    'holder_name': 'Shuhaib',
                    'balance': Decimal('0.00'),
                    'currency': 'SAR',
                    'status': 'Active',
                    'notes': 'Custody account for Shuhaib'
                },
                {
                    'name': 'Main Office Petty Cash',
                    'holder_name': 'Admin Office',
                    'balance': Decimal('0.00'),
                    'currency': 'SAR',
                    'status': 'Active',
                    'notes': 'Office operational float'
                }
            ]
            for a in default_accounts:
                PettyCashAccount.objects.create(
                    created_by=self.request.user if self.request.user.is_authenticated else None,
                    **a
                )
            qs = PettyCashAccount.objects.all().select_related('created_by')

        status_param = self.request.query_params.get('status')
        if status_param and status_param != 'All':
            qs = qs.filter(status__iexact=status_param)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(name__icontains=search) |
                Q(holder_name__icontains=search) |
                Q(notes__icontains=search)
            )
        return qs.order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=False, methods=['get'], url_path='summary')
    def summary(self, request):
        qs = PettyCashAccount.objects.all()
        total_balance = qs.aggregate(tot=Coalesce(Sum('balance'), Decimal('0'), output_field=DecimalField()))['tot']
        active_count = qs.filter(status='Active').count()
        total_count = qs.count()
        return Response({
            'total_balance': float(total_balance),
            'active_accounts': active_count,
            'total_accounts': total_count,
            'currency': 'SAR'
        })


class InvoiceViewSet(viewsets.ModelViewSet):
    serializer_class = InvoiceSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = Invoice.objects.all().select_related('customer', 'job_order', 'bank_account', 'created_by').prefetch_related('items', 'payments')
        
        customer_id = self.request.query_params.get('customer')
        if customer_id:
            qs = qs.filter(customer_id=customer_id)
            
        status_filter = self.request.query_params.get('status')
        if status_filter and status_filter.lower() != 'all':
            qs = qs.filter(status__iexact=status_filter)
            
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date:
            qs = qs.filter(invoice_date__gte=start_date)
        if end_date:
            qs = qs.filter(invoice_date__lte=end_date)
            
        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(invoice_number__icontains=search) |
                Q(customer__name__icontains=search) |
                Q(reference_number__icontains=search) |
                Q(job_order__title__icontains=search) |
                Q(job_order__order_id__icontains=search)
            )
            
        return qs.order_by('-invoice_date', '-created_at')

    def perform_create(self, serializer):
        user = self.request.user
        staff_name = user.get_full_name() or user.username
        serializer.save(created_by=user, created_by_staff=staff_name)

    @action(detail=False, methods=['get'], url_path='next-number')
    def next_number(self, request):
        """
        Generate the next sequential invoice number, e.g. INV-2026-0001
        """
        year = datetime.datetime.now().year
        prefix = f"INV-{year}-"
        last_invoice = Invoice.objects.filter(invoice_number__startswith=prefix).order_by('-id').first()
        if last_invoice:
            try:
                seq = int(last_invoice.invoice_number.split('-')[-1]) + 1
            except ValueError:
                seq = Invoice.objects.filter(invoice_number__startswith=prefix).count() + 1
        else:
            seq = 1
        next_num = f"{prefix}{seq:04d}"
        return Response({'next_number': next_num})

    @action(detail=True, methods=['get'], url_path='pdf')
    def pdf(self, request, pk=None):
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        from django.http import HttpResponse

        query_token = request.query_params.get('token')
        if query_token:
            from rest_framework_simplejwt.authentication import JWTAuthentication
            try:
                jwt_auth = JWTAuthentication()
                validated_token = jwt_auth.get_validated_token(query_token)
                request.user = jwt_auth.get_user(validated_token)
            except Exception:
                pass

        invoice = self.get_object()
        pdf_bytes = universal_pdf_generator.generate_tax_invoice_pdf(invoice)
        filename = format_dynamic_filename('tax_invoice', invoice.invoice_number, invoice.customer.name)
        
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response


class CustomFormFieldViewSet(viewsets.ModelViewSet):
    serializer_class = CustomFormFieldSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = None

    def get_queryset(self):
        qs = CustomFormField.objects.all().order_by('order', 'id')
        form_type = self.request.query_params.get('form_type')
        if form_type:
            qs = qs.filter(form_type=form_type)
        return qs


class MaterialCategoryViewSet(viewsets.ModelViewSet):
    serializer_class = MaterialCategorySerializer
    permission_classes = [IsAuthenticated]
    pagination_class = None
    queryset = MaterialCategory.objects.all().order_by('name')


class MaterialViewSet(viewsets.ModelViewSet):
    serializer_class = MaterialSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = None

    def get_queryset(self):
        qs = Material.objects.all().select_related('category', 'created_by').order_by('category__name', 'name')
        cat_id = self.request.query_params.get('category')
        if cat_id:
            qs = qs.filter(category_id=cat_id)
        search = self.request.query_params.get('q')
        if search:
            qs = qs.filter(
                Q(name__icontains=search) |
                Q(measurements__icontains=search) |
                Q(category__name__icontains=search) |
                Q(notes__icontains=search)
            )
        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class EstimationViewSet(viewsets.ModelViewSet):
    serializer_class = EstimationSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = None

    def get_queryset(self):
        qs = Estimation.objects.all().select_related('customer', 'created_by', 'converted_job').prefetch_related('items').order_by('-created_at')
        status_filter = self.request.query_params.get('status')
        if status_filter and status_filter != 'all':
            qs = qs.filter(status=status_filter)
        search = self.request.query_params.get('q')
        if search:
            qs = qs.filter(
                Q(title__icontains=search) |
                Q(estimate_number__icontains=search) |
                Q(client_name__icontains=search) |
                Q(customer__name__icontains=search)
            )
        return qs

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=['get'], url_path='client-pdf')
    def client_pdf(self, request, pk=None):
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        query_token = request.query_params.get('token')
        if query_token:
            from rest_framework_simplejwt.authentication import JWTAuthentication
            try:
                jwt_auth = JWTAuthentication()
                validated_token = jwt_auth.get_validated_token(query_token)
                request.user = jwt_auth.get_user(validated_token)
            except Exception:
                pass

        estimation = self.get_object()
        pdf_bytes = universal_pdf_generator.generate_client_estimation_checklist_pdf(estimation)
        filename = format_dynamic_filename('client_checklist', estimation.estimate_number, estimation.client_name or 'estimate')
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response

    @action(detail=True, methods=['get'], url_path='admin-pdf')
    def admin_pdf(self, request, pk=None):
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        query_token = request.query_params.get('token')
        if query_token:
            from rest_framework_simplejwt.authentication import JWTAuthentication
            try:
                jwt_auth = JWTAuthentication()
                validated_token = jwt_auth.get_validated_token(query_token)
                request.user = jwt_auth.get_user(validated_token)
            except Exception:
                pass

        estimation = self.get_object()
        pdf_bytes = universal_pdf_generator.generate_admin_estimation_pdf(estimation)
        filename = format_dynamic_filename('admin_estimate', estimation.estimate_number, estimation.client_name or 'estimate')
        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response

    @action(detail=True, methods=['post'], url_path='convert-to-job')
    def convert_to_job(self, request, pk=None):
        estimation = self.get_object()
        # Find or create customer
        customer = estimation.customer
        if not customer:
            c_name = estimation.client_name.strip() or 'Client'
            customer = Customer.objects.filter(name__iexact=c_name).first()
            if not customer:
                customer = Customer.objects.create(name=c_name, created_by=request.user)
            estimation.customer = customer

        # Generate Job Order ID
        last_job = JobOrder.objects.order_by('-id').first()
        new_num = 1
        if last_job and last_job.order_id and last_job.order_id.startswith('JOB-'):
            try:
                new_num = int(last_job.order_id.split('-')[1]) + 1
            except Exception:
                pass
        order_id = f"JOB-{new_num:04d}"

        # Compute prior balance for customer
        prev_jobs_tot = JobOrder.objects.filter(customer=customer).aggregate(
            tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        prev_inv_tot = Invoice.objects.filter(customer=customer, job_order__isnull=True).aggregate(
            tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        prev_cn_tot = CreditNote.objects.filter(customer=customer).exclude(
            status__in=['Draft', 'Cancelled']
        ).aggregate(
            tot=Coalesce(Sum('total_amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        prev_paid_tot = CustomerPayment.objects.filter(customer=customer).aggregate(
            tot=Coalesce(Sum('amount'), Decimal('0'), output_field=DecimalField())
        )['tot']
        prior_balance = max(Decimal('0'), (prev_jobs_tot + prev_inv_tot - prev_cn_tot) - prev_paid_tot)

        job = JobOrder.objects.create(
            order_id=order_id,
            title=f"Quote Ref {estimation.estimate_number}: {estimation.title}",
            description=f"Auto-converted from Estimation {estimation.estimate_number}.\n{estimation.notes}",
            customer=customer,
            status='In Progress',
            total_amount=estimation.total_price,
            prior_balance=prior_balance,
            quotation_number=estimation.estimate_number,
            created_by=request.user
        )

        estimation.converted_job = job
        estimation.status = 'Converted to Job'
        estimation.save()

        return Response({
            'success': True,
            'message': f'Estimation successfully converted to Job Order {job.order_id}',
            'job_order_id': job.id,
            'order_id': job.order_id
        }, status=status.HTTP_201_CREATED)


# -------------------------------------------------------------------------
# Quotation ViewSet
# -------------------------------------------------------------------------
class QuotationViewSet(viewsets.ModelViewSet):
    serializer_class = QuotationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = Quotation.objects.all().select_related(
            'customer', 'job_order', 'bank_account', 'converted_invoice', 'created_by'
        ).prefetch_related('items')

        customer_id = self.request.query_params.get('customer')
        if customer_id:
            qs = qs.filter(customer_id=customer_id)

        status_filter = self.request.query_params.get('status')
        if status_filter and status_filter.lower() != 'all':
            qs = qs.filter(status__iexact=status_filter)

        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date:
            qs = qs.filter(quotation_date__gte=start_date)
        if end_date:
            qs = qs.filter(quotation_date__lte=end_date)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(quotation_number__icontains=search) |
                Q(customer__name__icontains=search) |
                Q(reference_number__icontains=search) |
                Q(notes__icontains=search)
            )

        return qs.order_by('-quotation_date', '-created_at')

    def perform_create(self, serializer):
        user = self.request.user
        staff_name = user.get_full_name() or user.username
        serializer.save(created_by=user, created_by_staff=staff_name)

    @action(detail=False, methods=['get'], url_path='next-number')
    def next_number(self, request):
        year = datetime.datetime.now().year
        prefix = f"QT-{year}-"
        last = Quotation.objects.filter(quotation_number__startswith=prefix).order_by('-id').first()
        if last:
            try:
                seq = int(last.quotation_number.split('-')[-1]) + 1
            except ValueError:
                seq = Quotation.objects.filter(quotation_number__startswith=prefix).count() + 1
        else:
            seq = 1
        return Response({'next_number': f"{prefix}{seq:04d}"})

    @action(detail=True, methods=['get'], url_path='pdf')
    def pdf(self, request, pk=None):
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        from django.http import HttpResponse

        query_token = request.query_params.get('token')
        if query_token:
            from rest_framework_simplejwt.authentication import JWTAuthentication
            try:
                jwt_auth = JWTAuthentication()
                validated_token = jwt_auth.get_validated_token(query_token)
                request.user = jwt_auth.get_user(validated_token)
            except Exception:
                pass

        quotation = self.get_object()
        pdf_bytes = universal_pdf_generator.generate_quotation_pdf(quotation)
        filename = format_dynamic_filename('quotation', quotation.quotation_number, quotation.customer.name)

        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response

    @action(detail=True, methods=['post'], url_path='convert-to-invoice')
    def convert_to_invoice(self, request, pk=None):
        quotation = self.get_object()
        if quotation.converted_invoice:
            return Response({
                'detail': f'Quotation already converted to Invoice {quotation.converted_invoice.invoice_number}',
                'invoice_id': quotation.converted_invoice.id,
                'invoice_number': quotation.converted_invoice.invoice_number
            }, status=status.HTTP_400_BAD_REQUEST)

        year = datetime.datetime.now().year
        prefix = f"INV-{year}-"
        last_inv = Invoice.objects.filter(invoice_number__startswith=prefix).order_by('-id').first()
        if last_inv:
            try:
                seq = int(last_inv.invoice_number.split('-')[-1]) + 1
            except ValueError:
                seq = Invoice.objects.filter(invoice_number__startswith=prefix).count() + 1
        else:
            seq = 1
        inv_num = f"{prefix}{seq:04d}"

        invoice = Invoice.objects.create(
            invoice_number=inv_num,
            customer=quotation.customer,
            job_order=quotation.job_order,
            invoice_date=timezone.now().date(),
            payment_terms=quotation.payment_terms,
            status='Draft',
            reference_number=quotation.reference_number or f"From {quotation.quotation_number}",
            customer_tax_number=quotation.customer_tax_number,
            billing_address=quotation.billing_address,
            subtotal=quotation.subtotal,
            discount_amount=quotation.discount_amount,
            tax_rate=quotation.tax_rate,
            tax_amount=quotation.tax_amount,
            total_amount=quotation.total_amount,
            bank_account=quotation.bank_account,
            notes=quotation.notes,
            terms_conditions=quotation.terms_conditions,
            created_by=request.user,
            created_by_staff=request.user.get_full_name() or request.user.username,
            custom_fields=quotation.custom_fields or {}
        )

        for q_item in quotation.items.all():
            InvoiceItem.objects.create(
                invoice=invoice,
                description=q_item.description,
                quantity=q_item.quantity,
                unit=q_item.unit,
                unit_price=q_item.unit_price,
                discount_rate=q_item.discount_rate,
                tax_rate=q_item.tax_rate,
                tax_amount=q_item.tax_amount,
                total=q_item.total,
                sort_order=q_item.sort_order
            )

        quotation.converted_invoice = invoice
        quotation.status = 'Converted to Invoice'
        quotation.save()

        return Response({
            'success': True,
            'message': f'Quotation successfully converted to Invoice {invoice.invoice_number}',
            'invoice_id': invoice.id,
            'invoice_number': invoice.invoice_number
        }, status=status.HTTP_201_CREATED)


# -------------------------------------------------------------------------
# Credit Note ViewSet
# -------------------------------------------------------------------------
class CreditNoteViewSet(viewsets.ModelViewSet):
    serializer_class = CreditNoteSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = CreditNote.objects.all().select_related(
            'customer', 'invoice', 'created_by'
        ).prefetch_related('items')

        customer_id = self.request.query_params.get('customer')
        if customer_id:
            qs = qs.filter(customer_id=customer_id)

        status_filter = self.request.query_params.get('status')
        if status_filter and status_filter.lower() != 'all':
            qs = qs.filter(status__iexact=status_filter)

        reason_filter = self.request.query_params.get('reason')
        if reason_filter:
            qs = qs.filter(credit_reason=reason_filter)

        invoice_id = self.request.query_params.get('invoice')
        if invoice_id:
            qs = qs.filter(invoice_id=invoice_id)

        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date:
            qs = qs.filter(credit_note_date__gte=start_date)
        if end_date:
            qs = qs.filter(credit_note_date__lte=end_date)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(credit_note_number__icontains=search) |
                Q(customer__name__icontains=search) |
                Q(reference_number__icontains=search) |
                Q(invoice__invoice_number__icontains=search) |
                Q(notes__icontains=search)
            )

        return qs.order_by('-credit_note_date', '-created_at')

    def perform_create(self, serializer):
        user = self.request.user
        staff_name = user.get_full_name() or user.username
        serializer.save(created_by=user, created_by_staff=staff_name)

    @action(detail=False, methods=['get'], url_path='next-number')
    def next_number(self, request):
        year = datetime.datetime.now().year
        prefix = f"CN-{year}-"
        last = CreditNote.objects.filter(credit_note_number__startswith=prefix).order_by('-id').first()
        if last:
            try:
                seq = int(last.credit_note_number.split('-')[-1]) + 1
            except ValueError:
                seq = CreditNote.objects.filter(credit_note_number__startswith=prefix).count() + 1
        else:
            seq = 1
        return Response({'next_number': f"{prefix}{seq:04d}"})

    @action(detail=True, methods=['get'], url_path='pdf')
    def pdf(self, request, pk=None):
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        from django.http import HttpResponse

        query_token = request.query_params.get('token')
        if query_token:
            from rest_framework_simplejwt.authentication import JWTAuthentication
            try:
                jwt_auth = JWTAuthentication()
                validated_token = jwt_auth.get_validated_token(query_token)
                request.user = jwt_auth.get_user(validated_token)
            except Exception:
                pass

        credit_note = self.get_object()
        pdf_bytes = universal_pdf_generator.generate_credit_note_pdf(credit_note)
        filename = format_dynamic_filename('credit_note', credit_note.credit_note_number, credit_note.customer.name)

        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response


# -------------------------------------------------------------------------
# Delivery Note ViewSet
# -------------------------------------------------------------------------
class DeliveryNoteViewSet(viewsets.ModelViewSet):
    serializer_class = DeliveryNoteSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        qs = DeliveryNote.objects.all().select_related(
            'customer', 'job_order', 'invoice', 'created_by'
        ).prefetch_related('items')

        customer_id = self.request.query_params.get('customer')
        if customer_id:
            qs = qs.filter(customer_id=customer_id)

        status_filter = self.request.query_params.get('status')
        if status_filter and status_filter.lower() != 'all':
            qs = qs.filter(status__iexact=status_filter)

        job_order_id = self.request.query_params.get('job_order')
        if job_order_id:
            qs = qs.filter(job_order_id=job_order_id)

        invoice_id = self.request.query_params.get('invoice')
        if invoice_id:
            qs = qs.filter(invoice_id=invoice_id)

        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        if start_date:
            qs = qs.filter(delivery_date__gte=start_date)
        if end_date:
            qs = qs.filter(delivery_date__lte=end_date)

        search = self.request.query_params.get('search')
        if search:
            qs = qs.filter(
                Q(delivery_note_number__icontains=search) |
                Q(customer__name__icontains=search) |
                Q(driver_name__icontains=search) |
                Q(vehicle_number__icontains=search) |
                Q(receiver_name__icontains=search) |
                Q(tracking_number__icontains=search) |
                Q(customer_po_number__icontains=search) |
                Q(reference_number__icontains=search)
            )

        return qs.order_by('-delivery_date', '-created_at')

    def perform_create(self, serializer):
        user = self.request.user
        staff_name = user.get_full_name() or user.username
        serializer.save(created_by=user, created_by_staff=staff_name)

    @action(detail=False, methods=['get'], url_path='next-number')
    def next_number(self, request):
        year = datetime.datetime.now().year
        prefix = f"DN-{year}-"
        last = DeliveryNote.objects.filter(delivery_note_number__startswith=prefix).order_by('-id').first()
        if last:
            try:
                seq = int(last.delivery_note_number.split('-')[-1]) + 1
            except ValueError:
                seq = DeliveryNote.objects.filter(delivery_note_number__startswith=prefix).count() + 1
        else:
            seq = 1
        return Response({'next_number': f"{prefix}{seq:04d}"})

    @action(detail=True, methods=['get'], url_path='pdf')
    def pdf(self, request, pk=None):
        from .pdf_generator import universal_pdf_generator, format_dynamic_filename
        from django.http import HttpResponse

        query_token = request.query_params.get('token')
        if query_token:
            from rest_framework_simplejwt.authentication import JWTAuthentication
            try:
                jwt_auth = JWTAuthentication()
                validated_token = jwt_auth.get_validated_token(query_token)
                request.user = jwt_auth.get_user(validated_token)
            except Exception:
                pass

        delivery_note = self.get_object()
        pdf_bytes = universal_pdf_generator.generate_delivery_note_pdf(delivery_note)
        filename = format_dynamic_filename('delivery_note', delivery_note.delivery_note_number, delivery_note.customer.name)


        response = HttpResponse(pdf_bytes, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{filename}"'
        return response


class NotificationViewSet(viewsets.ModelViewSet):
    """
    Provides per-user notifications.
    GET  /api/notifications/                    — list my notifications
    POST /api/notifications/{id}/mark_read/     — mark one as read
    POST /api/notifications/mark_all_read/      — mark all as read
    """
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]
    http_method_names = ['get', 'post', 'patch', 'head', 'options']

    def get_queryset(self):
        qs = Notification.objects.filter(recipient=self.request.user).order_by('-created_at')
        unread_only = self.request.query_params.get('unread_only')
        if unread_only == 'true':
            qs = qs.filter(is_read=False)
        return qs

    @action(detail=True, methods=['post'], url_path='mark_read')
    def mark_read(self, request, pk=None):
        notification = self.get_object()
        notification.is_read = True
        notification.save(update_fields=['is_read'])
        return Response({'detail': 'Marked as read.'})

    @action(detail=False, methods=['post'], url_path='mark_all_read')
    def mark_all_read(self, request):
        Notification.objects.filter(recipient=request.user, is_read=False).update(is_read=True)
        return Response({'detail': 'All notifications marked as read.'})
