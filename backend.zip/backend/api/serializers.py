from rest_framework import serializers
from .models import Customer, Vendor, JobOrder, CustomerPayment, VendorPayment, Expense, Labour, PaymentRequest, ExpenseCategory, ExpenseType

class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = '__all__'

class VendorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vendor
        fields = '__all__'

class JobOrderLookupSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobOrder
        fields = ['id', 'order_id', 'title', 'total_amount', 'customer', 'vendor']

class JobOrderSerializer(serializers.ModelSerializer):
    customer_name = serializers.ReadOnlyField(source='customer.name')
    vendor_name = serializers.ReadOnlyField(source='vendor.name')
    paid_amount = serializers.SerializerMethodField()
    balance = serializers.SerializerMethodField()
    payment_history = serializers.SerializerMethodField()

    class Meta:
        model = JobOrder
        fields = '__all__'

    def get_paid_amount(self, obj):
        # Optimized to use prefetched data if available
        payments = getattr(obj, 'customer_payments', None)
        if payments is not None:
            # If using prefetch_related, this is much faster
            return sum(float(p.amount) for p in payments.all())
        return sum(float(p.amount) for p in obj.customer_payments.all())

    def get_balance(self, obj):
        paid = self.get_paid_amount(obj)
        return float(obj.total_amount) - paid

    def get_payment_history(self, obj):
        # Limit history in list view to keep it fast
        payments = obj.customer_payments.all()[:10]
        return [
            {
                "id": p.id,
                "amount": p.amount,
                "date": p.payment_date,
                "notes": p.notes
            } for p in payments
        ]

class CustomerPaymentSerializer(serializers.ModelSerializer):
    customer_name = serializers.ReadOnlyField(source='customer.name')
    job_order_title = serializers.ReadOnlyField(source='job_order.title')

    class Meta:
        model = CustomerPayment
        fields = '__all__'

class VendorPaymentSerializer(serializers.ModelSerializer):
    vendor_name = serializers.ReadOnlyField(source='vendor.name')
    job_order_title = serializers.ReadOnlyField(source='job_order.title')

    class Meta:
        model = VendorPayment
        fields = '__all__'

class ExpenseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ExpenseCategory
        fields = '__all__'

class ExpenseTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExpenseType
        fields = '__all__'

class ExpenseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Expense
        fields = '__all__'

from .models import SiteSettings

class SiteSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = SiteSettings
        fields = '__all__'

class LabourSerializer(serializers.ModelSerializer):
    vendor_name = serializers.ReadOnlyField(source='vendor.name')

    class Meta:
        model = Labour
        fields = '__all__'

class PaymentRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentRequest
        fields = '__all__'
