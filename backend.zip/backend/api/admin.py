from django.contrib import admin
from .models import (
    Customer, Vendor, JobOrder, CustomerPayment, VendorPayment,
    ExpenseCategory, ExpenseType, Expense, SiteSettings, Labour, PaymentRequest
)

@admin.register(JobOrder)
class JobOrderAdmin(admin.ModelAdmin):
    list_display = ('order_id', 'title', 'customer', 'status', 'total_amount', 'created_at')
    search_fields = ('order_id', 'title')

admin.site.register(Customer)
admin.site.register(Vendor)
admin.site.register(CustomerPayment)
admin.site.register(VendorPayment)
admin.site.register(ExpenseCategory)
admin.site.register(ExpenseType)
admin.site.register(Expense)
admin.site.register(SiteSettings)
admin.site.register(Labour)
admin.site.register(PaymentRequest)
