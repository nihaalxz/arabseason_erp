from django.shortcuts import render
from rest_framework import viewsets, permissions, status, views
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Sum, Count, Q, F, DecimalField, Subquery, OuterRef
from django.db.models.functions import TruncMonth, Coalesce
from django.utils import timezone
import datetime
import logging
from decimal import Decimal

logger = logging.getLogger(__name__)

from .models import (Customer, Vendor, JobOrder, CustomerPayment, VendorPayment, 
                     Expense, SiteSettings, PaymentRequest, ExpenseCategory, ExpenseType, Labour)
from .serializers import (CustomerSerializer, VendorSerializer, JobOrderSerializer, 
                          CustomerPaymentSerializer, VendorPaymentSerializer,
                          ExpenseSerializer, SiteSettingsSerializer,
                          JobOrderLookupSerializer, PaymentRequestSerializer,
                          ExpenseCategorySerializer, ExpenseTypeSerializer, LabourSerializer)

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all().order_by('name')
    serializer_class = CustomerSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)

class VendorViewSet(viewsets.ModelViewSet):
    queryset = Vendor.objects.all().order_by('name')
    serializer_class = VendorSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)

class JobOrderViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)


    def get_queryset(self):
        queryset = JobOrder.objects.all().select_related('customer', 'vendor').prefetch_related('customer_payments').order_by('-created_at')
        
        customer_id = self.request.query_params.get('customer')
        if customer_id:
            queryset = queryset.filter(customer_id=customer_id)
            
        status_filter = self.request.query_params.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)
            
        search_query = self.request.query_params.get('search')
        if search_query:
            queryset = queryset.filter(Q(title__icontains=search_query) | Q(order_id__icontains=search_query) | Q(customer__name__icontains=search_query))
            
        payment_status = self.request.query_params.get('payment_status')
        if payment_status:
            queryset = queryset.annotate(
                total_paid=Coalesce(Sum('customer_payments__amount'), Decimal('0'), output_field=DecimalField())
            )
            if payment_status == 'paid':
                queryset = queryset.filter(total_amount__lte=F('total_paid'))
            elif payment_status == 'unpaid':
                queryset = queryset.filter(total_amount__gt=F('total_paid'))
                
        return queryset

    def get_serializer_class(self):
        if self.request.query_params.get('lookup') == 'true':
            return JobOrderLookupSerializer
        return JobOrderSerializer

    @action(detail=False, methods=['get'])
    def titles(self, request):
        titles = JobOrder.objects.values_list('title', flat=True).distinct().order_by('title')
        return Response(list(titles))

class CustomerPaymentViewSet(viewsets.ModelViewSet):
    queryset = CustomerPayment.objects.all().select_related('customer', 'job_order').order_by('-payment_date')
    serializer_class = CustomerPaymentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = CustomerPayment.objects.all().select_related('customer', 'job_order').order_by('-payment_date')
        customer_id = self.request.query_params.get('customer')
        if customer_id:
            queryset = queryset.filter(customer_id=customer_id)
        job_order_id = self.request.query_params.get('job_order')
        if job_order_id:
            queryset = queryset.filter(job_order_id=job_order_id)
        return queryset

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)


class VendorPaymentViewSet(viewsets.ModelViewSet):
    queryset = VendorPayment.objects.all().select_related('vendor', 'job_order').order_by('-payment_date')
    serializer_class = VendorPaymentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = VendorPayment.objects.all().select_related('vendor', 'job_order').order_by('-payment_date')
        vendor_id = self.request.query_params.get('vendor')
        if vendor_id:
            queryset = queryset.filter(vendor_id=vendor_id)
        job_order_id = self.request.query_params.get('job_order')
        if job_order_id:
            queryset = queryset.filter(job_order_id=job_order_id)
        return queryset

class ExpenseViewSet(viewsets.ModelViewSet):
    serializer_class = ExpenseSerializer
    permission_classes = [IsAuthenticated]

    def list(self, request, *args, **kwargs):
        if request.query_params.get('nopage') == 'true':
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        return super().list(request, *args, **kwargs)


    def get_queryset(self):
        queryset = Expense.objects.all().select_related('vendor', 'job_order').order_by('-date')
        job_order = self.request.query_params.get('job_order')
        if job_order:
            queryset = queryset.filter(job_order_id=job_order)
        return queryset

class PaymentRequestViewSet(viewsets.ModelViewSet):
    queryset = PaymentRequest.objects.all().select_related('vendor').order_by('-created_at')
    serializer_class = PaymentRequestSerializer
    permission_classes = [IsAuthenticated]

class ExpenseCategoryViewSet(viewsets.ModelViewSet):
    queryset = ExpenseCategory.objects.all().order_by('name')
    serializer_class = ExpenseCategorySerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        name = str(request.data.get('name', '')).strip()
        if not name:
            return Response({"detail": "Name is required"}, status=status.HTTP_400_BAD_REQUEST)
            
        existing = ExpenseCategory.objects.filter(name__iexact=name).first()
        if existing:
            return Response({"detail": "Category already exists."}, status=status.HTTP_400_BAD_REQUEST)
            
        mutable_data = request.data.copy() if hasattr(request.data, 'copy') else dict(request.data)
        mutable_data['name'] = name
        serializer = self.get_serializer(data=mutable_data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if Expense.objects.filter(category=instance.name).exists():
            return Response({"message": "Cannot delete category as it is currently in use by one or more expenses."}, status=status.HTTP_400_BAD_REQUEST)
        return super().destroy(request, *args, **kwargs)

class ExpenseTypeViewSet(viewsets.ModelViewSet):
    queryset = ExpenseType.objects.all().order_by('name')
    serializer_class = ExpenseTypeSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        name = str(request.data.get('name', '')).strip()
        if not name:
            return Response({"detail": "Name is required"}, status=status.HTTP_400_BAD_REQUEST)
            
        existing = ExpenseType.objects.filter(name__iexact=name).first()
        if existing:
            return Response({"detail": "Type already exists."}, status=status.HTTP_400_BAD_REQUEST)
            
        mutable_data = request.data.copy() if hasattr(request.data, 'copy') else dict(request.data)
        mutable_data['name'] = name
        serializer = self.get_serializer(data=mutable_data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        if Expense.objects.filter(type=instance.name).exists():
            return Response({"message": "Cannot delete type as it is currently in use by one or more expenses."}, status=status.HTTP_400_BAD_REQUEST)
        return super().destroy(request, *args, **kwargs)

class LabourViewSet(viewsets.ModelViewSet):
    queryset = Labour.objects.all().select_related('vendor').order_by('-date')
    serializer_class = LabourSerializer
    permission_classes = [IsAuthenticated]

class DashboardAPIView(views.APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        start_date_str = request.query_params.get('start_date')
        end_date_str = request.query_params.get('end_date')
        
        if start_date_str and end_date_str:
            try:
                start_date = datetime.datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date = datetime.datetime.strptime(end_date_str, '%Y-%m-%d').date()
            except ValueError:
                end_date = timezone.now().date()
                start_date = end_date - datetime.timedelta(days=30)
        else:
            end_date = timezone.now().date()
            start_date = end_date - datetime.timedelta(days=30)
        
        total_customers = Customer.objects.count()
        total_job_orders = JobOrder.objects.filter(status__in=['Pending', 'In Progress']).count()
        
        income_range = {'payment_date__range': (start_date, end_date)}
        expense_range = {'date__range': (start_date, end_date)}
        labour_range = {'date__range': (start_date, end_date)}
        job_range = {'created_at__date__range': (start_date, end_date)}
        
        total_income = CustomerPayment.objects.filter(**income_range).aggregate(Sum('amount'))['amount__sum'] or 0
        total_exp = Expense.objects.filter(**expense_range).aggregate(Sum('amount'))['amount__sum'] or 0
        total_vend = PaymentRequest.objects.filter(status='Approved', created_at__date__range=(start_date, end_date)).aggregate(Sum('amount'))['amount__sum'] or 0
        total_labour = Labour.objects.filter(**labour_range).aggregate(Sum('payment_amount'))['payment_amount__sum'] or 0
        
        total_outgoing = float(total_exp) + float(total_vend) + float(total_labour)
        
        # Jobs by status in range
        jobs_in_range = JobOrder.objects.filter(**job_range)
        jobs_by_status = {
            'Pending': jobs_in_range.filter(status='Pending').count(),
            'In Progress': jobs_in_range.filter(status='In Progress').count(),
            'Completed': jobs_in_range.filter(status='Completed').count(),
            'Cancelled': jobs_in_range.filter(status='Cancelled').count(),
        }
        
        # Recent jobs
        recent_jobs = JobOrder.objects.all().select_related('customer').order_by('-created_at')[:5]
        recent_jobs_data = []
        for job in recent_jobs:
            recent_jobs_data.append({
                'id': job.id,
                'title': job.title,
                'customer_name': job.customer.name if job.customer else 'Unknown',
                'total_amount': float(job.total_amount)
            })

        # Trends
        daily_income = CustomerPayment.objects.filter(**income_range).values('payment_date').annotate(total=Sum('amount'))
        daily_expenses = Expense.objects.filter(**expense_range).values('date').annotate(total=Sum('amount'))
        daily_labour = Labour.objects.filter(**labour_range).values('date').annotate(total=Sum('payment_amount'))
        
        daily_trends = []
        curr = start_date
        while curr <= end_date:
            inc = next((i['total'] for i in daily_income if i['payment_date'] == curr), 0)
            exp = next((e['total'] for e in daily_expenses if e['date'] == curr), 0)
            lab = next((l['total'] for l in daily_labour if l['date'] == curr), 0)
            
            daily_trends.append({
                'date': str(curr), 
                'income': float(inc),
                'expenses': float(exp) + float(lab)
            })
            curr += datetime.timedelta(days=1)

        return Response({
            'total_customers': total_customers,
            'total_job_orders': total_job_orders,
            'total_income': float(total_income),
            'total_outgoing': total_outgoing,
            'jobs_by_status': jobs_by_status,
            'recent_jobs': recent_jobs_data,
            'daily_trends': daily_trends
        })

class ReportAPIView(views.APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]
    
    def get(self, request):
        try:
            start_date_str = request.query_params.get('start_date')
            end_date_str = request.query_params.get('end_date')
            
            if start_date_str and end_date_str:
                start_date = datetime.datetime.strptime(start_date_str, '%Y-%m-%d').date()
                end_date = datetime.datetime.strptime(end_date_str, '%Y-%m-%d').date()
            else:
                end_date = timezone.now().date()
                start_date = end_date - datetime.timedelta(days=365)

            # 1. Financial Trends (Safe from multi-joins as it's separate tables)
            monthly_income = CustomerPayment.objects.filter(payment_date__range=(start_date, end_date))\
                .annotate(month=TruncMonth('payment_date')).values('month').annotate(total=Sum('amount')).order_by('month')
            
            monthly_expenses = Expense.objects.filter(date__range=(start_date, end_date))\
                .annotate(month=TruncMonth('date')).values('month').annotate(total=Sum('amount')).order_by('month')

            # 2. Customer Aggregate using Subqueries to avoid cross-join multiplication
            cust_rev = JobOrder.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('total_amount')).values('total')[:1]
            cust_paid = CustomerPayment.objects.filter(customer=OuterRef('pk')).values('customer').annotate(total=Sum('amount')).values('total')[:1]

            customers = Customer.objects.annotate(
                total_jobs=Count('job_orders', distinct=True),
                rev_sum=Coalesce(Subquery(cust_rev, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
                paid_sum=Coalesce(Subquery(cust_paid, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0'))
            ).annotate(
                total_revenue=F('rev_sum'),
                balance=F('rev_sum') - F('paid_sum')
            ).values('id', 'name', 'email', 'phone', 'total_jobs', 'rev_sum', 'total_revenue', 'paid_sum', 'balance')

            # 3. Vendor Aggregate using Subqueries
            vend_purch = Expense.objects.filter(vendor=OuterRef('pk')).values('vendor').annotate(total=Sum('amount')).values('total')[:1]
            vend_paid = PaymentRequest.objects.filter(vendor=OuterRef('pk'), status='Approved').values('vendor').annotate(total=Sum('amount')).values('total')[:1]

            vendors = Vendor.objects.annotate(
                total_purchases=Count('expenses', distinct=True),
                purch_sum=Coalesce(Subquery(vend_purch, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0')),
                paid_sum=Coalesce(Subquery(vend_paid, output_field=DecimalField(max_digits=12, decimal_places=2)), Decimal('0'))
            ).annotate(
                total_paid=F('paid_sum'),
                balance=F('purch_sum') - F('paid_sum')
            ).values('id', 'name', 'business_group', 'email', 'phone', 'total_purchases', 'purch_sum', 'total_paid', 'balance')

            # 4. Job Orders Aggregate
            job_paid_sq = CustomerPayment.objects.filter(job_order=OuterRef('pk')).values('job_order').annotate(total=Sum('amount')).values('total')[:1]
            
            jobs = JobOrder.objects.select_related('customer').annotate(
                paid=Coalesce(Subquery(job_paid_sq, output_field=DecimalField()), Decimal('0')),
                balance=F('total_amount') - Coalesce(Subquery(job_paid_sq, output_field=DecimalField()), Decimal('0'))
            ).values('id', 'order_id', 'title', 'customer__name', 'status', 'total_amount', 'paid', 'balance')

            # 5. Job P&L (if job_id provided)
            job_id = request.query_params.get('job_id')
            job_pl = None
            if job_id:
                try:
                    job_obj = JobOrder.objects.get(id=job_id)
                    rev = CustomerPayment.objects.filter(job_order=job_obj).aggregate(Sum('amount'))['amount__sum'] or 0
                    exp = Expense.objects.filter(job_order=job_obj).aggregate(Sum('amount'))['amount__sum'] or 0
                    job_pl = {
                        'job_id': job_obj.id,
                        'title': job_obj.title,
                        'client_name': job_obj.customer.name if job_obj.customer else 'Unknown',
                        'status': job_obj.status,
                        'contract_total': float(job_obj.total_amount),
                        'revenue': float(rev),
                        'expenses': float(exp),
                        'profit': float(rev) - float(exp)
                    }
                except (JobOrder.DoesNotExist, ValueError): pass

            # 6. Expense Report Data
            expenses_qs = Expense.objects.all().order_by('-date')
            if start_date_str and end_date_str:
                expenses_qs = expenses_qs.filter(date__range=(start_date, end_date))
                
            opening_balance_qs = Expense.objects.filter(is_opening_balance=True, date__lte=end_date)
            opening_balance = opening_balance_qs.aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            
            all_income = CustomerPayment.objects.filter(payment_date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            all_exp = Expense.objects.filter(is_opening_balance=False, date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            all_vendor_req = PaymentRequest.objects.filter(status='Approved', created_at__date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            all_labour = Labour.objects.filter(date__lte=end_date).aggregate(Sum('payment_amount'))['payment_amount__sum'] or Decimal('0')
            all_vendor_pay = VendorPayment.objects.filter(payment_date__lte=end_date).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
            
            bank_balance = float(opening_balance) + float(all_income) - float(all_exp) - float(all_vendor_req) - float(all_labour) - float(all_vendor_pay)
            
            expense_list = list(expenses_qs.filter(is_opening_balance=False).values(
                'id', 'date', 'description', 'amount', 'category', 'type', 'notes'
            ))
            
            expense_report = {
                'opening_balance': float(opening_balance),
                'bank_balance': bank_balance,
                'closing_balance': bank_balance,
                'expenses': expense_list
            }

            # Safe date formatting helper
            def fmt_month(dt):
                if not dt: return ''
                if hasattr(dt, 'strftime'): return dt.strftime('%Y-%m')
                return str(dt)[:7] # Fallback for strings

            return Response({
                'monthly_income': [{'month': fmt_month(i['month']), 'total': float(i['total'] or 0)} for i in monthly_income],
                'monthly_expenses': [{'month': fmt_month(e['month']), 'total': float(e['total'] or 0)} for e in monthly_expenses],
                'customers': list(customers),
                'vendors': list(vendors),
                'jobs': [{**j, 'order_id': j['order_id'] or f"#JOB{j['id']}"} for j in jobs],
                'job_pl': job_pl,
                'expense_report': expense_report
            })

        except Exception as e:
            logger.exception("Report generation failed")
            return Response({'detail': str(e)}, status=500)

class SettingsAPIView(views.APIView):
    permission_classes = [IsAuthenticated, IsAdminUser]
    def get(self, request):
        s, _ = SiteSettings.objects.get_or_create(id=1)
        return Response(SiteSettingsSerializer(s).data)
    def post(self, request):
        s, _ = SiteSettings.objects.get_or_create(id=1)
        ser = SiteSettingsSerializer(s, data=request.data, partial=True)
        if ser.is_valid():
            ser.save()
            return Response(ser.data)
        return Response(ser.errors, status=400)

class ChangePasswordView(views.APIView):
    permission_classes = [IsAuthenticated]
    def post(self, request):
        u = request.user
        if not u.check_password(request.data.get('current_password')):
            return Response({'detail': 'Incorrect password'}, status=400)
        u.set_password(request.data.get('new_password'))
        u.save()
        return Response({'status': 'Password updated'})
