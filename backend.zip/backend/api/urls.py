from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    CustomerViewSet, VendorViewSet, JobOrderViewSet,
    CustomerPaymentViewSet, VendorPaymentViewSet, ExpenseViewSet,
    DashboardAPIView, ReportAPIView, SettingsAPIView, ChangePasswordView,
    LabourViewSet, PaymentRequestViewSet, ExpenseCategoryViewSet, ExpenseTypeViewSet
)

router = DefaultRouter()
router.register(r'customers', CustomerViewSet, basename='customers')
router.register(r'vendors', VendorViewSet, basename='vendors')
router.register(r'job-orders', JobOrderViewSet, basename='job-orders')
router.register(r'customer-payments', CustomerPaymentViewSet, basename='customer-payments')
router.register(r'vendor-payments', VendorPaymentViewSet, basename='vendor-payments')
router.register(r'expenses', ExpenseViewSet, basename='expenses')
router.register(r'labours', LabourViewSet, basename='labours')
router.register(r'payment-requests', PaymentRequestViewSet, basename='payment-requests')
router.register(r'expense-categories', ExpenseCategoryViewSet, basename='expense-categories')
router.register(r'expense-types', ExpenseTypeViewSet, basename='expense-types')

urlpatterns = [
    path('dashboard/', DashboardAPIView.as_view(), name='dashboard'),
    path('reports/', ReportAPIView.as_view(), name='reports'),
    path('settings/', SettingsAPIView.as_view(), name='settings'),
    path('change-password/', ChangePasswordView.as_view(), name='change_password'),
    path('', include(router.urls)),
]
