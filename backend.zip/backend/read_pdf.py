import sys
import PyPDF2

try:
    with open(sys.argv[1], 'rb') as f:
        reader = PyPDF2.PdfReader(f)
        text = ""
        for i, page in enumerate(reader.pages):
            text += f"--- Page {i+1} ---\n"
            text += page.extract_text() + "\n"
        with open('prompt_output_utf8.txt', 'w', encoding='utf-8') as out_f:
            out_f.write(text)
except Exception as e:
    with open('prompt_output_utf8.txt', 'w', encoding='utf-8') as out_f:
        out_f.write(f"Error: {e}")
