import os
import django
import sys

# Set up Django environment
sys.path.append(r'c:\Users\shaha\Arabseason book\backend')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

from api.models import JobOrder, CustomerPayment
from api.serializers import JobOrderSerializer

def verify_calculations():
    print("--- Verifying Job Order Calculations ---")
    jobs = JobOrder.objects.all()
    if not jobs.exists():
        print("No job orders found to verify.")
        return

    for job in jobs:
        serializer = JobOrderSerializer(job)
        data = serializer.data
        print(f"Job: {job.title} (ID: {job.id})")
        print(f"  Total Amount: {job.total_amount}")
        print(f"  Paid Amount (Serializer): {data['paid_amount']}")
        print(f"  Balance (Serializer): {data['balance']}")
        
        # Manual calculation
        from django.db.models import Sum
        actual_paid = CustomerPayment.objects.filter(job_order=job).aggregate(Sum('amount'))['amount__sum'] or 0
        actual_balance = float(job.total_amount) - float(actual_paid)
        
        print(f"  Actual Paid (DB): {actual_paid}")
        print(f"  Actual Balance (Calc): {actual_balance}")
        
        if float(data['paid_amount']) == float(actual_paid) and float(data['balance']) == float(actual_balance):
            print("  [SUCCESS] Calculation matches.")
        else:
            print("  [FAILURE] Calculation mismatch!")

if __name__ == "__main__":
    verify_calculations()
