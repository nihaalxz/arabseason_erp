import os, django, sys, traceback
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from rest_framework.test import APIClient
from django.contrib.auth import get_user_model

try:
    User = get_user_model()
    c = APIClient(HTTP_HOST='localhost')
    u = User.objects.first()
    if u:
        c.force_authenticate(user=u)
        
    print("Testing /api/dashboard/")
    try:
        res = c.get('/api/dashboard/')
        print('DASH STATUS:', res.status_code)
        if res.status_code == 500:
            print(res.content.decode())
    except Exception as e:
        print("DASHBOARD EXCEPTION:")
        traceback.print_exc()

    print("\nTesting /api/reports/")
    try:
        res = c.get('/api/reports/')
        print('REP STATUS:', res.status_code)
        if res.status_code == 500:
            print(res.content.decode())
    except Exception as e:
        print("REPORTS EXCEPTION:")
        traceback.print_exc()
except Exception as e:
    traceback.print_exc()
