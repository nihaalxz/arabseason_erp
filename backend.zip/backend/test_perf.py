import os, django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()
from rest_framework.test import APIClient
from django.contrib.auth import get_user_model

c = APIClient(SERVER_NAME='localhost')
c.force_authenticate(user=get_user_model().objects.first())

import cProfile, pstats
cProfile.run("c.get('/api/dashboard/')", 'restats')
p = pstats.Stats('restats')
p.sort_stats('tottime').print_stats(30)
