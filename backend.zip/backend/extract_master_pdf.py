import PyPDF2

def extract_pdf_text():
    text = ''
    try:
        with open('c:\\Users\\shaha\\Arabseason book\\Arabseason_ERP_Master_Prompt.pdf', 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text += page.extract_text() + '\n'
        with open('c:\\Users\\shaha\\Arabseason book\\master_prompt.txt', 'w', encoding='utf-8') as f:
            f.write(text)
        print('Extraction successful.')
    except Exception as e:
        print('Extraction failed:', str(e))

if __name__ == '__main__':
    extract_pdf_text()
